function [nodeset_best, t_best, objval, nodeset] = gcp_multiple(Xp, E, w, sigma2)

num_ticks = size(Xp, 1);
num_features = size(Xp, 2);
num_nodes = size(Xp, 3);
num_edges = size(E, 2);
lambda = 2 * (32 + log(num_nodes + num_edges)) * sigma2;

Xz = bsxfun(@rdivide, Xp, std(Xp, [], 1) + 1e-5);

S = zeros(num_ticks+1, num_features, num_nodes);
S(2:end, :, :) = cumsum(Xz, 1);
delta = zeros(size(Xz));
for t = 2:num_ticks
    l = max(t-w, 1);
    r = min(t+w, num_ticks);
    
    mu = (S(r+1,:,:) - S(l,:,:)) / (r - l + 1);
    left_mean = (S(t, :, :) - S(l, :, :)) / (t-l);
    right_mean = (S(r+1, :, :) - S(t, :, :)) / (r-t+1);
    delta(t, :, :) = (t-l) * (left_mean - mu).^2 + (r-t+1) * (right_mean - mu).^2;
end

%%
prizes = reshape(sum(delta, 2), [num_ticks, num_nodes]);
objval = nan(num_ticks, 1);
nodeset = cell(num_ticks, 1);
edgeset = cell(num_ticks, 1);

for t = 2:num_ticks
    [nodeset{t}, edgeset{t}] = run_pcst(E(:)', prizes(t,:), lambda *  ones(1, num_edges), -1, 1, 'strong');
    objval(t) = sum(prizes(t, nodeset{t})) - lambda * length(nodeset{t});
end
%%
S = zeros(1, num_ticks);
for t = 2:num_ticks
    conflicts = max(1, t-2*w) : t-1;
    conflicts = intersect(conflicts, find(S));
    trees_intersect = nan(length(conflicts));
    for conflict_idx = 1:length(conflicts)
        cur_t = conflicts(conflict_idx);
        trees_intersect(conflict_idx) = ~isempty(intersect(nodeset{t}, nodeset{cur_t}));
    end
    conflicts = conflicts(trees_intersect == 1);
    
    conflict_sum = sum(objval(conflicts));
    if objval(t) > conflict_sum
        S(t) = 1;
        S(conflicts) = 0;
    end
end

%%
nodeset_best = nodeset(S == 1)';
t_best = find(S);
    