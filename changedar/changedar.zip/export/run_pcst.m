% Note: for calling python code, all vectors should be expressed as 1 x D 
% edges: 1 x n matrix 
function [nodeset, edgeset] = run_pcst(edges, prizes, costs, root, num_clusters, pruning)

% if matlab cannot find python packages that you have installed, this is
% sometimes because it does not have the right path. In this case, the path
% to your libraries has to be added manually as follows. 

% P = py.sys.path;
% libpath = '/Users/bryanhooi/anaconda/lib/python2.7/site-packages/';
% if count(P, libpath) == 0
%     insert(P,int32(0), libpath);
% end
% py.importlib.import_module('numpy');
% py.importlib.import_module('pcst_fast');

p_edges = py.numpy.array(edges - 1, 'int64');
p_edges = p_edges.reshape(int32(length(edges) / 2), int32(2));
p_prizes = py.numpy.array(prizes);
p_costs = py.numpy.array(costs);

res = py.pcst_fast.pcst_fast(p_edges, p_prizes, p_costs, int32(root), int32(num_clusters), pruning, int32(0));
nodeset = double(py.array.array('d', res{1})) + 1;
edgeset = double(py.array.array('d', res{2})) + 1;