
sigma2 = 1.5;  % error variance
w = 5;  % window size

% * E is an m x 2 list of edges that forms the static graph of sensors: e.g.
%   if [i j] is a row of E, the graph has an edge from node i to j
% * speed_data is a (num_ticks) x 1 x (num_sensors) matrix, representing the
%   value at each time for each sensor. (The 2nd dimension is 1 because we
%   have only 1 feature here, which is speed, but if we had more features,
%   the 2nd dimension would be the number of features.)
load('export/example_speed_data.mat', 'speed_data', 'E');

% Run change detection algorithm
% INPUT:
% speed_data: matrix of values at each time of each sensor
% * E: list of edges
% * w: window size
% * sigma2: error variance
% OUTPUT:
% * change_sets: cell array of the sensor ids involved in each detected change
% * change_times: the time of each detected change
% * objval: information gain objective value
% * (the 4th argument is the information gain at each time, and can be
% ignored (for debugging purposes only). 
[change_sets, change_times, objval, ~] = gcp_multiple(speed_data, E', w, sigma2);