
function Tree = fastMST(Data)
num_features = 100;
[m,n] = size(Data);
rand_mat = randi(2, n, num_features) * 2 - 3; % random matrix of 1 and -1
features = Data * rand_mat;
% [features, ~, ~] = svds(Data, num_features);

fid=fopen('features.csv','w');
tempstr = repmat('%f,',1,num_features);
tempstr(end) = char(10);
fprintf(fid,tempstr,features.');
fclose(fid);

system('../LIB/emst --input_file=features.csv --output_file=mst.csv');
mst = csvread('mst.csv');
delete('features.csv', 'mst.csv');
% duplicate into symmetric matrix
mst2 = [mst(:,1), mst(:,2), mst(:,3); mst(:,2), mst(:,1), mst(:,3)];
% convert zero index to one indexed; perturb zero edge weights
Tree = sparse(1+mst2(:, 1), 1+mst2(:, 2), mst2(:, 3)+1e-4, m, m);
end