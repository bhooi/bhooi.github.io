function Data = generate_toy_data_kron()
n = 4;%10;
K1 = zeros(n,n);

for i = 1: n
    for j = 1: n
        if i>=j
            K1(i,j) = 1;
        end
    end
end
figure;

for i=1:2
  K1 = kron(K1, K1);
end
Data = K1;
