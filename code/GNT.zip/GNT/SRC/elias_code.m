
function encoded = elias_code(idx)
bin = dec2bin(idx);
leading = repmat('0', 1, length(bin)-1);
encoded = sprintf('%s%s', leading, bin);
end