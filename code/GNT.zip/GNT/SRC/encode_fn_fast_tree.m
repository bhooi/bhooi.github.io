function [encoding, encoding_con, Nbits_cum, NelRv_cum, Nbits, NelRv] = encode_fn_fast_tree(Data)

if ~issparse(Data)
  Data = sparse(Data);
end

% encode Data and Data' and return the method with better ALOC (with a
% switch bit to encode which we did)
[encoding1, ~, Nbits_cum1, NelRv_cum1, Nbits1, NelRv1] = encode_fn_fast_tree_method1(Data);
ALOC1 = ALOC_fn(Nbits_cum1, NelRv_cum1);
[encoding2, ~, Nbits_cum2, NelRv_cum2, Nbits2, NelRv2] = encode_fn_fast_tree_method2(Data);
ALOC2 = ALOC_fn(Nbits_cum2, NelRv_cum2);

if ALOC1 < ALOC2
  encoding = encoding1;
  Nbits = Nbits1;
  NelRv = NelRv1;
  indicator = '0';
else
  encoding = encoding2;
  Nbits = Nbits2;
  NelRv = NelRv2;
  indicator = '1';
end

encoding = [indicator, encoding];
NelRv = [0, NelRv];
Nbits = [1, Nbits];

Nbits_cum = cumsum(Nbits);
NelRv_cum = cumsum(NelRv);
encoding_con = strjoin(encoding, '');
end

