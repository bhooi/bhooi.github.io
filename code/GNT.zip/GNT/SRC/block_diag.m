function [Data, idx_mapping_row, idx_mapping_col, r_block_info3, c_block_info3, diag_score_max, empty_score_max] = block_diag(Data, K, r_id_block_cl, c_id_block_cl, idx_mapping_row, idx_mapping_col)

perm_list = perms(1:K);

for i = 1: length(perm_list)
    cl_order_row = perm_list(i,:);
    
    for j = 1: length(perm_list)
        cl_order_col = perm_list(j,:);
        
        for ii = 1: length(cl_order_row)
            cl_order_row_now = cl_order_row(ii);
            cl_order_col_now = cl_order_col(ii);
            row_tmp = r_id_block_cl(cl_order_row_now,1):r_id_block_cl(cl_order_row_now,2);
            col_tmp = c_id_block_cl(cl_order_col_now,1):c_id_block_cl(cl_order_col_now,2);
            Data_tmp2_block = Data(row_tmp, col_tmp);
            density_block(ii) = sum(sum(Data_tmp2_block));
            empty_block_tmp(ii) = sum(sum(Data_tmp2_block==0));
        end
        diag_score(i,j) = sum(density_block);
        empty_score(i,j) = sum(empty_block_tmp);
    end
end


%%

[val1, ind1] = max(diag_score);
[val2, ind2] = max(val1);
row_perm_ind = ind1(ind2);
col_perm_ind = ind2;
diag_score_max = val2;
empty_score_max = empty_score(row_perm_ind, col_perm_ind);

cl_order_row = perm_list(row_perm_ind,:);
Data_tmp = [];
idx_mapping_row2 = [];

for ii = 1: length(cl_order_row)
    cl_order_row_now = cl_order_row(ii);
    row_block = Data(r_id_block_cl(cl_order_row_now,1):r_id_block_cl(cl_order_row_now,2),:);
    Data_tmp = [Data_tmp; row_block];
    if ii == 1
        r_block_info(1,1) = 1;
        r_block_info(1,2) = size(Data_tmp,1);
    else
        r_block_info(ii,1) = r_block_info(ii-1,2)+1;
        r_block_info(ii,2) = size(Data_tmp,1);
    end
    lin_sp = r_id_block_cl(cl_order_row_now,1):r_id_block_cl(cl_order_row_now,2);
    idx_mapping_row2 = [idx_mapping_row2 idx_mapping_row(lin_sp)];
end
idx_mapping_row = idx_mapping_row2;
clear idx_mapping_row2

Data_tmp2 = [];
idx_mapping_col2 = [];

cl_order_col = perm_list(col_perm_ind,:);
for jj = 1: length(cl_order_col)
    cl_order_col_now = cl_order_col(jj);
    col_block = Data_tmp(:,c_id_block_cl(cl_order_col_now,1):c_id_block_cl(cl_order_col_now,2));
    Data_tmp2 = [Data_tmp2 col_block];
    if jj == 1
        c_block_info(1,1) = 1;
        c_block_info(2,1) = size(Data_tmp2,2);
    else
        c_block_info(1,jj) = c_block_info(2,jj-1)+1;
        c_block_info(2,jj) = size(Data_tmp2,2);
    end
    lin_sp = c_id_block_cl(cl_order_col_now,1):c_id_block_cl(cl_order_col_now,2);
    idx_mapping_col2 = [idx_mapping_col2 idx_mapping_col(lin_sp)];
end
idx_mapping_col = idx_mapping_col2;
clear idx_mapping_col2

Data = Data_tmp2;


%%
% put the heaviest (more full. considers (1) # of 1s in the block, (2) size
% of the block) block diagonal to the top left.
for i = 1: K
    blck_now = Data(r_block_info(i,1):r_block_info(i,2),c_block_info(1,i):c_block_info(2,i));
    diag_dens_score(i) = sum(sum(blck_now)) / size(blck_now,1) /size(blck_now,2);
end
[val, ind] = sort(diag_dens_score, 'descend');
% for i = 1: K
Data_tmp = [];
idx_mapping_row2 = [];
for j = 1: length(ind)
    diag_ind_now = ind(j);
    blck_now = Data(r_block_info(diag_ind_now,1):r_block_info(diag_ind_now,2),:);
    Data_tmp = [Data_tmp; blck_now];
    if j == 1
        r_block_info3(j,1) = 1;
        r_block_info3(j,2) = size(Data_tmp,1);
    else
        r_block_info3(j,1) = r_block_info3(j-1,2)+1;
        r_block_info3(j,2) = size(Data_tmp,1);
    end
    lin_sp = r_block_info(diag_ind_now,1):r_block_info(diag_ind_now,2);
    idx_mapping_row2 = [idx_mapping_row2 idx_mapping_row(lin_sp)];
end
idx_mapping_row = idx_mapping_row2;
clear idx_mapping_row2

Data_tmp2 = [];
idx_mapping_col2 = [];
for j = 1: length(ind)
    diag_ind_now = ind(j);
    blck_now = Data_tmp(:, c_block_info(1,diag_ind_now):c_block_info(2,diag_ind_now));
    Data_tmp2 = [Data_tmp2 blck_now];
    if j == 1
        c_block_info3(1,j) = 1;
        c_block_info3(2,j) = size(Data_tmp2,2);
    else
        c_block_info3(1,j) = c_block_info3(2,j-1)+1;
        c_block_info3(2,j) = size(Data_tmp2,2);
    end
    lin_sp =  c_block_info(1,diag_ind_now):c_block_info(2,diag_ind_now);
    idx_mapping_col2 = [idx_mapping_col2 idx_mapping_col(lin_sp)];
end
idx_mapping_col = idx_mapping_col2;
clear idx_mapping_col2
% end


Data = Data_tmp2;