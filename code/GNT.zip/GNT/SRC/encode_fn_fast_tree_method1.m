function [encoding, encoding_con, Nbits_cum, NelRv_cum, Nbits, NelRv] = encode_fn_fast_tree_method1(Data)

if ~issparse(Data)
  Data = sparse(Data);
end

% encode Data and Data' and return the method with better ALOC (with a
% switch bit to encode which we did)
[encoding1, ~, Nbits_cum1, NelRv_cum1, Nbits1, NelRv1] = encode_matrix(Data);
ALOC1 = ALOC_fn(Nbits_cum1, NelRv_cum1);
[encoding2, ~, Nbits_cum2, NelRv_cum2, Nbits2, NelRv2] = encode_matrix(Data');
ALOC2 = ALOC_fn(Nbits_cum2, NelRv_cum2);

if ALOC1 < ALOC2
  encoding = encoding1;
  Nbits = Nbits1;
  NelRv = NelRv1;
  indicator = '0';
else
  encoding = encoding2;
  Nbits = Nbits2;
  NelRv = NelRv2;
  indicator = '1';
end

encoding = [indicator, encoding];
NelRv = [0, NelRv];
Nbits = [1, Nbits];

Nbits_cum = cumsum(Nbits);
NelRv_cum = cumsum(NelRv);
encoding_con = strjoin(encoding, '');
end

function [encoding, encoding_con, Nbits_cum, NelRv_cum, Nbits, NelRv] = encode_matrix(Data)
[m,n] = size(Data);
bin_n_table = generate_binary(ceil(log2(n)));
bin_m_table = generate_binary(ceil(log2(m)));

Tree = fastMST(Data);

[~, first_row] = max(sum(Data, 2));

[disc, pred, ~] = graphtraverse(Tree, first_row, 'Directed', false);
disc_inv = zeros(size(disc));
disc_inv(disc) = 1:m; % inverse permutation of disc


encoding = {};
Nbits = [];
NelRv = [];
el_idx = 1;

% start with root
start_idx = disc(1);

% encode first row index
[el_idx, encoding, Nbits, NelRv] = update_enc(el_idx, encoding, Nbits, NelRv, 0, bin_m_table(:, start_idx)');

enc = sprintf('%s', num2str(Data(start_idx, :), '%d'));
[el_idx, encoding, Nbits, NelRv] = update_enc(el_idx, encoding, Nbits, NelRv, sum(Data(start_idx, :)), enc);
% end
%   
% % termination character
% [el_idx, encoding, Nbits, NelRv] = update_enc(el_idx, encoding, Nbits, NelRv, 0, '0');

tData = Data';
coded = -ones(1,n);
curcode = 1;
for i = 2:m
  cur = disc(i);
  % encode each difference between cur and anc
  elem = sum(tData(:, cur));
%   fprintf('ENCODING %d WITH PARENT %d\n', cur, pred(cur));
  diffs = find(tData(:, cur) - tData(:, pred(cur)));
%   fprintf('NOW CODING ERRORS:\n');
  curnew = curcode - 1;
  numnew = 0;
  encnew = '';
  for j = 1:size(diffs, 1)
    if coded(diffs(j)) == -1
      numnew = numnew + 1;
%       fprintf('not seen %d before: code is %d\n', diffs(j), curcode);
      coded(diffs(j)) = curcode;
      curcode = curcode + 1;
%       fprintf('set curcode to %d\n', curcode);
    else
      encnew = sprintf('%s%s', encnew, encode_binary(coded(diffs(j)), curnew));
%       fprintf('**seen before as %d, encnew is %s\n', coded(diffs(j)), encnew);
    end
  end
  if size(diffs, 1) == 0
    enc = sprintf('%s%s', encode_binary(disc_inv(pred(cur)), i-1), elias_code(size(diffs, 1)));
  else
    enc = sprintf('%s%s%s%s', encode_binary(disc_inv(pred(cur)), i-1), elias_code(size(diffs, 1)), elias_code(numnew), encnew);
  end
%   fprintf('OUTPUT ENCODING: %s\n', enc);
  [el_idx, encoding, Nbits, NelRv] = update_enc(el_idx, encoding, Nbits, NelRv, elem, enc);
end
Nbits_cum = cumsum(Nbits);
NelRv_cum = cumsum(NelRv);
encoding_con = strjoin(encoding, '');

end