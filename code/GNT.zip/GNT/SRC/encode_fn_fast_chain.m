function [encoding, encoding_con, Nbits_cum, NelRv_cum, Nbits, NelRv] = encode_fn_fast_chain(Data)
[m,n] = size(Data);

[i,j] = find(Data);
fid=fopen('Data_chain.csv','w');
fprintf(fid, '%d %d\n', m, n);
fprintf(fid,'%d %d\n', [i,j]');
fclose(fid);
system('python ./fast_chain.py Data_chain.csv');
ordering = csvread('fast_chain_out.csv');

delete('fast_chain_out.csv', 'Data_chain.csv');

bin_n_table = generate_binary(ceil(log2(n)));
encoding = {};
Nbits = [];
NelRv = [];
el_idx = 1;

enc = sprintf('%s', num2str(Data(ordering(1), :), '%d'));
[el_idx, encoding, Nbits, NelRv] = update_enc(el_idx, encoding, Nbits, NelRv, sum(Data(ordering(1), :)), enc);
tData = Data';
for i = 2:m
  r1 = ordering(i-1);
  r2 = ordering(i);
  elem = sum(Data(r2, :));
  enc = '';
  diffs = find(tData(:, r1) - tData(:, r2));
  for j = 1:size(diffs, 1)
    enc = sprintf('%s1%s', enc, bin_n_table(:, diffs(j)));
  end
  enc = sprintf('%s0', enc);
  [el_idx, encoding, Nbits, NelRv] = update_enc(el_idx, encoding, Nbits, NelRv, elem, enc);
end
Nbits_cum = cumsum(Nbits);
NelRv_cum = cumsum(NelRv);
encoding_con = strjoin(encoding, '');

