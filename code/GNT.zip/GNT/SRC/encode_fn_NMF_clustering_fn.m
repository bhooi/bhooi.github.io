function [encoding_Onion, encoding_con_Onion, Nbits_cum_Onion, NelRv_cum_Onion] = encode_fn_NMF_clustering_fn(Data, K)

if nargin < 2
  K = 5;
end


% K = 5;
[Y, row_c,col_c] = partition_using_nmf(Data,K);
% figure
% spy(Data)
% 
% figure
% spy(Y)

iii = 1;
for i = 1: K
    idx = find(row_c == i);
    for ii = 1: length(idx)
        Data2(iii,:) = Data(idx(ii),:);
        iii = iii  +1;
    end
    N_r_block(i) = sum(row_c == i);
end
iii = 1;
for j = 1: K
    idx = find(col_c == j);
    for ii = 1: length(idx)
        Data3(:,iii) = Data2(:,idx(ii));
        iii = iii  +1;
    end
    N_c_block(j) = sum(col_c == j);
end
   k = K;
l = K;
clear Data Data2
Data = Data3;
clear Data3


%% encode_fn_Onion_multi_fin3.m

for i = 1: k
    
    for j = 1: l
        
        if (i == 1 && j == 1)
            BlockNow = Data( 1 : sum(N_r_block(1:i)) , 1 : sum(N_c_block(1:j)));
        elseif i==1 && j ~=1
            BlockNow = Data( 1 : sum(N_r_block(1:i)) , sum(N_c_block(1:j-1)) +1 : sum(N_c_block(1:j)));
        elseif i~=1 && j==1
            BlockNow = Data( sum(N_r_block(1:i-1)) +1 : sum(N_r_block(1:i)) , 1 : sum(N_c_block(1:j)));
        else
            BlockNow = Data( sum(N_r_block(1:i-1)) +1 : sum(N_r_block(1:i)) , sum(N_c_block(1:j-1)) +1 : sum(N_c_block(1:j)));
        end
        
        BlockScore1(i,j) = sum(sum(BlockNow))/(size(BlockNow,1)*size(BlockNow,2)) * sqrt(size(BlockNow,1) * size(BlockNow,2));
%         BlockScore2(i,j) = sum(sum(BlockNow))/(size(BlockNow,1)*size(BlockNow,2))  ;
        
%         figure;imagesc(BlockNow);
        
    end
    
end

for i = 1: k 
    if i == 1
        r_block_info(i,1) = 1;
        r_block_info(i,2) = N_r_block(1);
    else
         r_block_info(i,1) = sum(N_r_block(1:i-1)) +1;
        r_block_info(i,2) = sum(N_r_block(1:i));
    end
end
for j = 1: l
    if j == 1
        c_block_info(1,j) = 1;
        c_block_info(2,j) = N_c_block(1);
    else
         c_block_info(1,j) = sum(N_c_block(1:j-1)) +1;
        c_block_info(2,j) = sum(N_c_block(1:j));
    end
end


cSumBlockScore = sum(BlockScore1,1);
rSumBlockScore = sum(BlockScore1,2);
[val, ind1] =sort(cSumBlockScore, 'descend');
cCum = 0;
for j = 1: l
    DataNew(:,cCum + 1: cCum + (c_block_info(2,ind1(j)) - c_block_info(1,ind1(j))) +1) = Data(:, c_block_info(1,ind1(j)): c_block_info(2,ind1(j)));
      
    c_block_info2(1,j) = cCum + 1;
    c_block_info2(2,j) = size(DataNew,2);
    cCum = size(DataNew,2);
end
% figure;imagesc(DataNew);


[val, ind2] =sort(rSumBlockScore, 'descend');
rCum = 0;
for i = 1: k
    DataNew2(rCum + 1: rCum + (r_block_info(ind2(i),2) - r_block_info(ind2(i),1)) +1,  :) = DataNew(r_block_info(ind2(i),1): r_block_info(ind2(i),2),:);
    
      r_block_info2(i,1) = rCum + 1;
    r_block_info2(i,2) = size(DataNew2,1);
    rCum = size(DataNew2,1);
end
% figure;imagesc(DataNew2);


%%% after sorting:
% DataNew2
% r_block_info2
% c_block_info2
Data = DataNew2;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % % % % for i = 1: k
% % % % %     N_r_block(i) = sum(Qx == i);
% % % % % end
% % % % % for j = 1: l
% % % % %     N_c_block(j) = sum(Qy == j);
% % % % % end
   

% for i = 1: size(Data,1)
%     
%   
%     for j = 1: size(Data,1)
% 
%         % similarity measure
%         RSim(i,j) = sum(abs(Data(i,:) - Data(j,:))) / size(Data,1);
%        
%     end
%     
% end
% 
% for i = 1: size(Data,2)
%     for j = 1:size(Data,2)
%         CSim(i,j) = sum(abs(Data(:,i) - Data(:,j))) / size(Data,2);
%     end
% end
% 
% % figure;imagesc(RSim);
% % figure;imagesc(CSim);
% 
% 
% 
% for i = 1: k 
%     if i == 1
%         r_block_info(i,1) = 1;
%         r_block_info(i,2) = N_r_block(1);
%     else
%          r_block_info(i,1) = sum(N_r_block(1:i-1)) +1;
%         r_block_info(i,2) = sum(N_r_block(1:i));
%     end
% end
% for j = 1: l
%     if j == 1
%         c_block_info(1,j) = 1;
%         c_block_info(2,j) = N_c_block(1);
%     else
%          c_block_info(1,j) = sum(N_c_block(1:j-1)) +1;
%         c_block_info(2,j) = sum(N_c_block(1:j));
%     end
% end
% 
%  [v, i]= max(sum(Data,1));
% referR = i;
%  [v, i]= max(sum(Data,2));
% referC = i;
% Data_sort = Data;
% 
% [v, indR] = sort(RSim(referR,:), 'descend');
% 
% [v, indC] = sort(CSim(referC,:), 'descend');
% 
% Data_sort2 = Data;
% for i = 1: size(Data,1)
%     Data_sort(i,:) = Data(indR(i),:);
% end
% 
% for j = 1: size(Data,2)
%     Data_sort2(:,j) = Data_sort(:,indC(j));
% end
% 
% % figure;imagesc(Data_sort);
% % figure;imagesc(Data_sort2);




%% block sort
% % % % % 
% % % % % for i = 1: k
% % % % %     N_r_block(i) = sum(Qx == i);
% % % % % end
% % % % % for j = 1: l
% % % % %     N_c_block(j) = sum(Qy == j);
% % % % % end
% % % % %    
% % % % % 
% % % % % for i = 1: k
% % % % %          if (i == 1)
% % % % %             BlockNow1 = Data( 1 : sum(N_r_block(1:i)) , :);
% % % % %      
% % % % %       
% % % % %          else
% % % % %             BlockNow1 = Data( sum(N_r_block(1:i-1)) +1 : sum(N_r_block(1:i)) , :);
% % % % %          end
% % % % %         
% % % % %          
% % % % %          
% % % % %          
% % % % %          
% % % % %     for j = 1: k
% % % % %         
% % % % %         if (  j == 1)
% % % % %             BlockNow2 = Data( 1 : sum(N_r_block(1:j)) , :);
% % % % %        
% % % % %         else
% % % % %             BlockNow2 = Data( sum(N_r_block(1:j-1)) +1 : sum(N_r_block(1:j)) , :);
% % % % %         end
% % % % %         
% % % % %         BlockNow11 = sum(BlockNow1,1) / size(BlockNow1,1);
% % % % %         BlockNow22 = sum(BlockNow2,1) / size(BlockNow2,1);
% % % % %         
% % % % % %         BlockScore1(i,j) = sum(sum(BlockNow))/(size(BlockNow,1)*size(BlockNow,2)) * sqrt(size(BlockNow,1) * size(BlockNow,2));
% % % % % %         BlockScore2(i,j) = sum(sum(BlockNow))/(size(BlockNow,1)*size(BlockNow,2))  ;
% % % % %         BlockScore1_r(i,j) = sum(abs(BlockNow11 - BlockNow22)) / size(BlockNow11,2);
% % % % % %         figure;imagesc(BlockNow);
% % % % %         
% % % % %     end
% % % % %     
% % % % % end
% % % % % 
% % % % % 
% % % % % 
% % % % % %%%%%%%%%%%%%%%% col
% % % % % for i = 1: l
% % % % %       if ( i == 1)
% % % % %             BlockNow1 = Data( : , 1 : sum(N_c_block(1:i)));
% % % % %         elseif  i ~=1
% % % % %             BlockNow1 = Data( : , sum(N_c_block(1:i-1)) +1 : sum(N_c_block(1:i)));
% % % % % 
% % % % %       end
% % % % %     for j = 1: l
% % % % %         
% % % % %         if ( j == 1)
% % % % %             BlockNow2 = Data( :, 1 : sum(N_c_block(1:j)));
% % % % %         else
% % % % %             BlockNow2 = Data( :, sum(N_c_block(1:j-1)) +1 : sum(N_c_block(1:j)));
% % % % %         end
% % % % %         
% % % % %           BlockNow11 = sum(BlockNow1,2) / size(BlockNow1,2);
% % % % %         BlockNow22 = sum(BlockNow2,2) / size(BlockNow2,2);
% % % % %         
% % % % % %         BlockScore1(i,j) = sum(sum(BlockNow))/(size(BlockNow,1)*size(BlockNow,2)) * sqrt(size(BlockNow,1) * size(BlockNow,2));
% % % % % %         BlockScore2(i,j) = sum(sum(BlockNow))/(size(BlockNow,1)*size(BlockNow,2))  ;
% % % % %         BlockScore1_c(i,j) = sum(abs(BlockNow11 - BlockNow22)) / size(BlockNow11,1);
% % % % % %         figure;imagesc(BlockNow);
% % % % %         
% % % % %         
% % % % %     end
% % % % %     
% % % % % end
% % % % % 
% % % % % 
% % % % % %%
% % % % % %%
% % % % % %%
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % %%
% % % % % clear DataNew
% % % % % % DataNew = Data;
% % % % % [val, ind1] =sort(BlockScore1_c(1,:), 'ascend');
% % % % % [val, ind2] =sort(BlockScore1_r(1,:), 'ascend');
% % % % % % cSumBlockScore = sum(BlockScore1_c,1);
% % % % % % rSumBlockScore = sum(BlockScore1_r,2);
% % % % % % [val, ind1] =sort(cSumBlockScore, 'descend');
% % % % % cCum = 0;
% % % % % for j = 1: l
% % % % %     DataNew(:,cCum + 1: cCum + (c_block_info2(2,ind1(j)) - c_block_info2(1,ind1(j))) +1) = Data(:, c_block_info2(1,ind1(j)): c_block_info2(2,ind1(j)));
% % % % %       
% % % % %     c_block_info3(1,j) = cCum + 1;
% % % % %     c_block_info3(2,j) = size(DataNew,2);
% % % % %     cCum = size(DataNew,2);
% % % % % end
% % % % % % figure;imagesc(DataNew);
% % % % % 
% % % % % clear DataNew2
% % % % % % [val, ind2] =sort(rSumBlockScore, 'descend');
% % % % % rCum = 0;
% % % % % for i = 1: k
% % % % %     DataNew2(rCum + 1: rCum + (r_block_info2(ind2(i),2) - r_block_info2(ind2(i),1)) +1,  :) = DataNew(r_block_info2(ind2(i),1): r_block_info2(ind2(i),2),:);
% % % % %     
% % % % %       r_block_info3(i,1) = rCum + 1;
% % % % %     r_block_info3(i,2) = size(DataNew2,1);
% % % % %     rCum = size(DataNew2,1);
% % % % % end
% % % % % % figure;imagesc(DataNew2);
% % % % % 
% % % % % 
% % % % % %%% after sorting:
% % % % % % DataNew2
% % % % % % r_block_info2
% % % % % % c_block_info2
% % % % % Data = DataNew2;


%%



n = size(Data,1);
m = size(Data,2);

% figure;imagesc(Data);


%% Dot-By-Dot
% [encoding_DBD, encoding_con_DBD, Nbits_cum_DBD, NelRv_cum_DBD] = encode_fn_DBD(Data);
% 
% % Compute Area Left of the Curve (ALOC)
% [ALOC_DBD] = ALOC_fn(Nbits_cum_DBD, NelRv_cum_DBD);
% disp(['ALOC - DBD = ' num2str(ALOC_DBD)]);
% % Slope - min, avg, median
% [Slope_min_DBD, Slope_median_DBD, Slope_avg_DBD] = Slopes_fn(Nbits_cum_DBD, NelRv_cum_DBD);
% disp(['Slope_min - DBD = ' num2str(Slope_min_DBD)]);
% disp(['Slope_median - DBD = ' num2str(Slope_median_DBD)]);
% disp(['Slope_avg - DBD = ' num2str(Slope_avg_DBD)]);

r_block_info3 = r_block_info2;
c_block_info3 = c_block_info2;

%% Onion
encoding_Onion = [];
encoding_con_Onion = [];
Nbits_cum_Onion = [];
NelRv_cum_Onion = [];

for i = 1: k
    for j = 1: l
        onesMtrx = zeros(size(Data,1),size(Data,2));
       onesMtrx(r_block_info3(i,1):r_block_info3(i,2), c_block_info3(1,j):c_block_info3(2,j) ) = 1;
        BlockNow = Data .*  onesMtrx;
        missingBlock = (1 - Data) .*  onesMtrx;
        
%         BlockNow = Data(r_block_info2(i,1):r_block_info2(i,2), c_block_info2(1,j):c_block_info2(2,j) );
        if sum(sum(BlockNow)) ~= 0
            
%             [decision1, encoding_Onion1, encoding_con_Onion1, Nbits_cum_Onion1, NelRv_cum_Onion1] = onion_kronecker_fn_missing( onesMtrx,BlockNow, missingBlock);
            [encoding_Onion1, encoding_con_Onion1, Nbits_cum_Onion1, NelRv_cum_Onion1] = onion_kronecker_fn_missing_satellite(BlockNow);
%             decision(i,j) = decision1;
%             figure;imagesc(BlockNow);
            %         [y, i] = min([Nbits_cum_Onion1(end) Nbits_cum_Onion2(end) Nbits_cum_Onion3(end) Nbits_cum_Onion4(end)]);
            
            for ii = 1: size(encoding_Onion1,1)
                encoding_Onion{end + 1,1} = encoding_Onion1{ii,1};
            end
            encoding_con_Onion = [encoding_con_Onion encoding_con_Onion1];
            if size(Nbits_cum_Onion,2) == 0
                Nbits_cum_Onion = [Nbits_cum_Onion Nbits_cum_Onion1];
                NelRv_cum_Onion = [NelRv_cum_Onion NelRv_cum_Onion1];
            else
                Nbits_cum_Onion = [Nbits_cum_Onion (Nbits_cum_Onion(size(Nbits_cum_Onion,2))+Nbits_cum_Onion1)];
                NelRv_cum_Onion = [NelRv_cum_Onion (NelRv_cum_Onion(size(NelRv_cum_Onion,2))+NelRv_cum_Onion1)];
            end
            
            %          disp(['Onion direction: ' num2str(i)]);

        end
    end
end