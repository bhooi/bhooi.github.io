function Data = generate_toy_data_multi_block()
  n = 20;
  m = 20;

  Data = zeros(n,m);
%   Data(1:6, 1:6) = ones(6, 6);
%   Data(5:8, 5:8) = ones(4, 4);
 Data(1:6, 1:6) = ones(6, 6);
  Data(8:12, 8:12) = ones(5, 5);
%   Data(5:10, 5:10) = ones(6, 6);
%   Data(9:12, 9:12) = ones(4, 4);
  
  