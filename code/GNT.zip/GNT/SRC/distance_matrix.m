function dist = distance_matrix(Data)
[m,n] = size(Data);
dist = zeros(m, m);
for i = 1:m
  dist(i, :) = sum(abs(Data - ones(m, 1) * Data(i, :)), 2);
end
dist
end