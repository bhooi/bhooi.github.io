
% generate table of binary numbers of length n
function tab = generate_binary(n)
tab = ['0' '1'];
for i=2:n
  sz = size(tab, 2);
  tab = [repmat('0', 1, sz), repmat('1', 1, sz); tab, tab];
end
end