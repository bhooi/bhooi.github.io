function chain_order = reorder_chain(Data, start_idx)
[m,n] = size(Data);
dist = distance_matrix(Data);
remaining = ones(1, m);

chain_order = [start_idx];

remaining(start_idx) = 0;
cur = start_idx;
for i = 1:(m-1)
  d_row = dist(cur, :);
  best_idx = -1;
  best_cost = Inf;
  % greedily search for row closest to cur (which hasn't been encoded yet)
  for j = 1:m
    if remaining(j) == 1 && d_row(j) < best_cost
      best_idx = j;
      best_cost = d_row(j);
    end
  end
  chain_order(end + 1) = best_idx;
  remaining(best_idx) = 0;
  cur = best_idx;
end
end