function [ALOC] = ALOC_fn(Nbits_cum, NelRv_cum)

ALOC = 0;
for i = 1: length(Nbits_cum)
    if i> 1
        ALOC = ALOC + (NelRv_cum(i) - NelRv_cum(i-1)) * (Nbits_cum(i) + Nbits_cum(i-1)) /2;
    elseif i == 1
        ALOC = ALOC + (NelRv_cum(i) - 0) * (Nbits_cum(i) + 0) /2;
    end
end