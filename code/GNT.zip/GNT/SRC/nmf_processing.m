function [Data, r_id_block_cl, c_id_block_cl, idx_mapping_row, idx_mapping_col] = nmf_processing(Data_in, K)


disp('nmf...');
[Y, row_c,col_c] = partition_using_nmf(Data_in,K);
Data = Data_in;


disp('nmf post...');
iii = 1;
Data2 = [];
idx_mapping_row = [];
for i = 1: K
    idx = find(row_c == i);
    Data2 = [Data2; Data(idx,:)];
    idx_mapping_row = [idx_mapping_row; idx]; % to map the original data to the re-ordered matrix.
    
    N_r_block(i) = sum(row_c == i);
end
idx_mapping_row = idx_mapping_row';
iii = 1;
Data3 = [];
idx_mapping_col = [];
for j = 1: K
    idx = find(col_c == j);
    Data3 = [Data3 Data2(:,idx)];
    idx_mapping_col = [idx_mapping_col; idx];
    
    N_c_block(j) = sum(col_c == j);
end
idx_mapping_col = idx_mapping_col';
k = K;
l = K;
clear Data Data2
Data = Data3;
clear Data3


r_id_block_cl(1,1) = 1;
r_id_block_cl(1,2) = N_r_block(1);
for i = 1: K-1
    r_id_block_cl(i+1,1) = r_id_block_cl(i,2)+1;
    r_id_block_cl(i+1,2) = r_id_block_cl(i+1,1) + N_r_block(i+1)-1;
end
c_id_block_cl(1,1) = 1;
c_id_block_cl(1,2) = N_c_block(1);
for i = 1: K-1
    c_id_block_cl(i+1,1) = c_id_block_cl(i,2)+1;
    c_id_block_cl(i+1,2) = c_id_block_cl(i+1,1) + N_c_block(i+1)-1;
end