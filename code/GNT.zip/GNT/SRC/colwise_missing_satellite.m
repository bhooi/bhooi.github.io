function [encoding, encoding_con, Nbits, NelRv, Data2,iter, i_end_flag, j_end_flag] = colwise_missing_satellite(cum_i, cum_j, Data2, Data,encoding, encoding_con, Nbits, NelRv, iter)

            %% column-wise block extension
                n = size(Data2,1);
            m = size(Data2,2);
%             
%             cum_i = iii-1+0;
%             cum_j = firstblocksize_j;
%             
            i = 1;
            j = 1;
            
            
                       % if at least 2x2 square block is formed, go on to onion,
            % otherwise, leave it as it is for DBD later.
            if sum(sum(Data2(cum_i+i:cum_i+i+1,cum_j+j:cum_j+j+1))) == 4
            
            
            % first element
            
            [encoding_tmp, encoding_con_tmp, Nbits_cum2_tmp, NelRv_cum2_tmp, Nbits_tmp, NelRv_tmp] = encode_fn_DBD2(cum_i+i,cum_j+j);
            lencoding = size(encoding,1);
            encoding{lencoding+1,1} = encoding_tmp{1};
            
            encoding_con = [encoding_con encoding_con_tmp];
            Nbits = [Nbits Nbits_tmp];
            NelRv = [NelRv NelRv_tmp];
            
            iter = iter + 1;
            Data2(cum_i+i,cum_j+j) = 0;
            
            % second element
            j = j + 1; %%%%%%%%%%%%%%%%%
            [encoding_tmp, encoding_con_tmp, Nbits_cum2_tmp, NelRv_cum2_tmp, Nbits_tmp, NelRv_tmp] = encode_fn_DBD2(cum_i+i,cum_j+j);
            lencoding = size(encoding,1);
            encoding{lencoding+1,1} = encoding_tmp{1};
            %     encoding{lencoding+2,1} = encoding_tmp{2};
            encoding_con = [encoding_con encoding_con_tmp];
            Nbits = [Nbits Nbits_tmp];
            NelRv = [NelRv NelRv_tmp];
            
            iter = iter + 1; %2;
            Data2(cum_i+i,cum_j+j) = 0;
            
            
            
            
            %%%%%%%%%%%%%% added 0129 ->need to oapply to other codes too
            if cum_i+i == n
                i_end_flag = 1;
            else
               i_end_flag = 0; 
            end
            if cum_j+j == m
                j_end_flag = 1;
            else
                j_end_flag = 0;
            end
            
            
            
%             i_end_flag = 0;
%             j_end_flag = 0;
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            
            
            
            
            
            % while (i<=n) && (j<=m) % within given matrix
            %     while block_flag == 1 % within block cluster
            
            while (i_end_flag~=1) || (j_end_flag~=1)
                if (i_end_flag ~=1)
                    if sum(sum(abs(Data2(cum_i+i+1,cum_j+1:cum_j+j) - ones(1,j))))==0
                        v = dec2bin(1,2); % property is 'A-like'
                        
                        i_st_bin = dec2bin(cum_i+1);
                        li_st = length(i_st_bin);
                        i_st_bin = dec2bin(cum_i+1,li_st*2);
                        
                        i_bin = dec2bin(cum_i+i+1);
                        li = length(i_bin);
                        i_bin = dec2bin(cum_i+i+1,li*2);
                        
                        encoding{iter,:} = [i_bin v i_st_bin];
                        encoding_con = [encoding_con  encoding{iter,:}];
                        
                        Nbits(iter) = length(encoding{iter,:});
                        
                        NelRv(iter) = j;
                        
                        iter = iter + 1;
                        Data2(cum_i+i+1,cum_j+1:cum_j+j) = 0;
                        i = i + 1;
                    else
                        
                           Nbits1 = Nbits;
                        NelRv1 = NelRv;
                         Nbits2 = Nbits;
                        NelRv2 = NelRv;
                        encoding1 = encoding;
                        encoding2 = encoding;
                        encoding_con1 = encoding_con;
                        encoding_con2 = encoding_con;
                        iter1 = iter;
                        iter2 = iter;
                        
                        % first proceed
                        
                            v = dec2bin(1,2); % property is 'A-like'
                        
                        i_st_bin = dec2bin(cum_i+1);
                        li_st = length(i_st_bin);
                        i_st_bin = dec2bin(cum_i+1,li_st*2);
                        
                        i_bin = dec2bin(cum_i+i+1);
                        li = length(i_bin);
                        i_bin = dec2bin(cum_i+i+1,li*2);
                        
                        encoding1{iter,:} = [i_bin v i_st_bin];
                        encoding_con1 = [encoding_con1  encoding1{iter,:}];
                        
                        Nbits1(iter1) = length(encoding1{iter,:});
                        
                        NelRv1(iter1) = j;
                        
                        iter1 = iter1 + 1;
%                         Data2(cum_i+i+1,cum_j+1:cum_j+j) = 0;
%                         i = i + 1;
                        
                          % left over - DBD - missing part encoding
                        PartNow = (Data2(cum_i+i+1,cum_j+1:cum_j+j) ) * (-1) + 1;
                        %%% missing parts by DBD
                        
                        [d1, d2] = find(PartNow);
                        for ii = 1: length(d1)
                            [encoding_tmp, encoding_con_tmp, Nbits_cum2_tmp, NelRv_cum2_tmp, Nbits_tmp, NelRv_tmp] = encode_fn_DBD2(d1(ii),d2(ii));
                            lencoding1 = size(encoding1,1);
                            encoding1{lencoding1+1,1} = encoding_tmp{1};
                            %     encoding{lencoding+2,1} = encoding_tmp{2};
                            encoding_con1 = [encoding_con1 encoding_con_tmp];
                            Nbits1 = [Nbits1 Nbits_tmp];
                            NelRv1 = [NelRv1 NelRv_tmp];
                            
                            iter1 = iter1 + 1; %2;
%                                 Data2_1(d1(ii), d2(ii)) = 0;
                        end
                        
                        
                         % DBD
                       PartNow = (Data2(cum_i+i+1,cum_j+1:cum_j+j));
                        %%% missing parts by DBD
                        
                        [d1, d2] = find(PartNow);
                        for ii = 1: length(d1)
                            [encoding_tmp, encoding_con_tmp, Nbits_cum2_tmp, NelRv_cum2_tmp, Nbits_tmp, NelRv_tmp] = encode_fn_DBD2(d1(ii),d2(ii));
                            lencoding2 = size(encoding2,1);
                            encoding2{lencoding2+1,1} = encoding_tmp{1};
                            %     encoding{lencoding+2,1} = encoding_tmp{2};
                            encoding_con2 = [encoding_con2 encoding_con_tmp];
                            Nbits2 = [Nbits2 Nbits_tmp];
                            NelRv2 = [NelRv2 NelRv_tmp];
                            
                            iter2 = iter2 + 1; %2;
%                             Data2_2(d1(ii), d2(ii)) = 0;
                        end
                        
                          if length(encoding_con1) < length(encoding_con2) % Onion+missing better
                            Data2(cum_i+i+1,cum_j+1:cum_j+j) = 0;
                              i = i + 1;
                              
                             encoding = encoding1;
                             encoding_con = encoding_con1;
                             Nbits = Nbits1;
                             NelRv = NelRv1;
                             iter = iter1;
                             
                             clear encoding1 encoding2 encoding_con1 encoding_con2 Nbits1 Nbits2 NelRv1 NelRv2 iter1 iter2
                        else  % DBD better
                           Data2(cum_i+i+1,cum_j+1:cum_j+j) = 0;
                              i_end_flag = 1;
                              
                             encoding = encoding2;
                             encoding_con = encoding_con2;
                             Nbits = Nbits2;
                             NelRv = NelRv2;
                             iter = iter2;
                             clear encoding1 encoding2 encoding_con1 encoding_con2 Nbits1 Nbits2 NelRv1 NelRv2 iter1 iter2
                        end
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
%                         i_end_flag = 1;
                    end
                    if cum_i+i == n
                        i_end_flag = 1;
                    end
                end
                % i>2 && j >1 % onion peeling start
                %         if i > j
                if (j_end_flag ~=1)
                    if sum(sum(abs(Data2(cum_i+1:cum_i+i,cum_j+j+1) - ones(i,1))))==0
                        v = dec2bin(2,2); % property is 'P-like'
                        
                        j_st_bin = dec2bin(cum_j+1);
                        lj_st = length(j_st_bin);
                        j_st_bin = dec2bin(cum_j+1,lj_st*2);
                        
                        j_bin = dec2bin(cum_j+j+1);
                        lj = length(j_bin);
                        j_bin = dec2bin(cum_j+j+1,lj*2);
                        
                        encoding{iter,:} = [j_bin v j_st_bin];
                        encoding_con = [encoding_con  encoding{iter,:}];
                        
                        Nbits(iter) = length(encoding{iter,:});
                        
                        NelRv(iter) = i;
                        
                        
                        
                        iter = iter + 1;
                        Data2(cum_i+1:cum_i+i,cum_j+j+1) = 0;
                        j = j + 1;
                    else
                        
                         Nbits1 = Nbits;
                        NelRv1 = NelRv;
                         Nbits2 = Nbits;
                        NelRv2 = NelRv;
                        encoding1 = encoding;
                        encoding2 = encoding;
                        encoding_con1 = encoding_con;
                        encoding_con2 = encoding_con;
                        iter1 = iter;
                        iter2 = iter;
                        
                        % first proceed
                         v = dec2bin(2,2); % property is 'P-like'
                        
                        j_st_bin = dec2bin(cum_j+1);
                        lj_st = length(j_st_bin);
                        j_st_bin = dec2bin(cum_j+1,lj_st*2);
                        
                        j_bin = dec2bin(cum_j+j+1);
                        lj = length(j_bin);
                        j_bin = dec2bin(cum_j+j+1,lj*2);
                        
                        encoding1{iter1,:} = [j_bin v j_st_bin];
                        encoding_con1 = [encoding_con1  encoding1{iter1,:}];
                        
                        Nbits1(iter1) = length(encoding1{iter1,:});
                        
                        NelRv1(iter1) = i;
                        
                        
                        
                        iter1 = iter1 + 1;
%                         Data2(cum_i+1:cum_i+i,cum_j+j+1) = 0;
%                         j = j + 1;
                        
                        
                           
                        % left over - DBD - missing part encoding
                        PartNow = (Data2(cum_i+1:cum_i+i,cum_j+j+1)) * (-1) + 1;
                        %%% missing parts by DBD
                        
                        [d1, d2] = find(PartNow);
                        for ii = 1: length(d1)
                            [encoding_tmp, encoding_con_tmp, Nbits_cum2_tmp, NelRv_cum2_tmp, Nbits_tmp, NelRv_tmp] = encode_fn_DBD2(d1(ii),d2(ii));
                            lencoding1 = size(encoding1,1);
                            encoding1{lencoding1+1,1} = encoding_tmp{1};
                            %     encoding{lencoding+2,1} = encoding_tmp{2};
                            encoding_con1 = [encoding_con1 encoding_con_tmp];
                            Nbits1 = [Nbits1 Nbits_tmp];
                            NelRv1 = [NelRv1 NelRv_tmp];
                            
                            iter1 = iter1 + 1; %2;
%                                 Data2_1(d1(ii), d2(ii)) = 0;
                        end
                        
                        
                        
                        
                        
                        
                        % DBD
                       PartNow = (Data2(cum_i+1:cum_i+i,cum_j+j+1));
                        %%% missing parts by DBD
                        
                        [d1, d2] = find(PartNow);
                        for ii = 1: length(d1)
                            [encoding_tmp, encoding_con_tmp, Nbits_cum2_tmp, NelRv_cum2_tmp, Nbits_tmp, NelRv_tmp] = encode_fn_DBD2(d1(ii),d2(ii));
                            lencoding2 = size(encoding2,1);
                            encoding2{lencoding2+1,1} = encoding_tmp{1};
                            %     encoding{lencoding+2,1} = encoding_tmp{2};
                            encoding_con2 = [encoding_con2 encoding_con_tmp];
                            Nbits2 = [Nbits2 Nbits_tmp];
                            NelRv2 = [NelRv2 NelRv_tmp];
                            
                            iter2 = iter2 + 1; %2;
%                             Data2_2(d1(ii), d2(ii)) = 0;
                        end
                        
                        
                        
                        
                        if length(encoding_con1) < length(encoding_con2) % Onion+missing better
                             Data2(cum_i+1:cum_i+i,cum_j+j+1) = 0;
                             j = j + 1;
                             
                             encoding = encoding1;
                             encoding_con = encoding_con1;
                             Nbits = Nbits1;
                             NelRv = NelRv1;
                             iter = iter1;
                             
                             clear encoding1 encoding2 encoding_con1 encoding_con2 Nbits1 Nbits2 NelRv1 NelRv2 iter1 iter2
                        else  % DBD better
                             Data2(cum_i+1:cum_i+i,cum_j+j+1) = 0;
                              j_end_flag = 1;
                              
                             encoding = encoding2;
                             encoding_con = encoding_con2;
                             Nbits = Nbits2;
                             NelRv = NelRv2;
                             iter = iter2;
                             clear encoding1 encoding2 encoding_con1 encoding_con2 Nbits1 Nbits2 NelRv1 NelRv2 iter1 iter2
                        end
                        
                        
                        
                        
%                         j_end_flag = 1;
                    end
                    if cum_j + j == m
                        j_end_flag = 1;
                    end
                    % % % % %         end
                end
                %         elseif (i==j)
                
                
                
                
                
                % % % % %     end
                % end
                % end
            end
            
            
            end
            