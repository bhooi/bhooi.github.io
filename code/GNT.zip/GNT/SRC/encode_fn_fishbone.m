function [encoding, encoding_con, Nbits_cum, NelRv_cum, Nbits, NelRv] = encode_fn_fishbone(Data)
[~, col_ord] = sort(sum(Data, 1), 'descend');
[~, row_ord] = sort(sum(Data, 2), 'descend');
[m,n] = size(Data);

% [List0, List1] = hyperbolic_ordering(Data);
% order1 = unique([List0 + 1, 1:m], 'stable');
% order2 = unique([List1 + 1, 1:n], 'stable');
Data2 = Data(row_ord, col_ord);
el_idx = 1;
Nbits = [];
NelRv = [];
encoding = {};
tot = sum(sum(Data2));

for i = 1:min(m,n)
  [best_length, errors] = best_encoding_length(Data2(i, i:n));
  elem = sum(Data2(i, i:n));
  enc = strcat(encode_binary(best_length, n), encode_errors(errors, n));
  [el_idx, encoding, Nbits, NelRv] = update_enc(el_idx, encoding, Nbits, NelRv, elem, enc);
  
  [best_length, errors] = best_encoding_length(Data2(i + 1 : m, i));
  elem = sum(Data2(i + 1 : m, i));
  enc = strcat(encode_binary(best_length, m), encode_errors(errors, m));
  [el_idx, encoding, Nbits, NelRv] = update_enc(el_idx, encoding, Nbits, NelRv, elem, enc);
  if sum(NelRv) == tot
    break
  end
end
Nbits_cum = cumsum(Nbits);
NelRv_cum = cumsum(NelRv);
encoding_con = strjoin(encoding, '');

end

% given errors, construct the string to encode these errors (delimited by
% '1' and terminated by '0')
function enc = encode_errors(errors, n)
enc = '';
for j = 1:length(errors)
  enc = sprintf('%s1%s', enc, encode_binary(errors(j), n));
end
enc = sprintf('%s0', enc);
end

% given a vector, we want to encode the first k as a consecutive block, and
% encode everything else using dot by dot, where we may encode the missing
% ones in the consecutive block. This tries all lengths k to find the
% shortest encoding length.
function [best_len, errors] = best_encoding_length(v)
stop_threshold = 50;
n = length(v);
cur_sum = 0;
tot = sum(v);
best_cost = sum(v);
best_len = 0;
for i=1:n
  cur_sum = cur_sum + v(i);
  missing = i - cur_sum;
  needed = tot - cur_sum;
  enc_cost = missing + needed;
  if enc_cost < best_cost
    best_cost = enc_cost;
    best_len = i;
  end
  if enc_cost > best_cost + stop_threshold
    break
  end
end
mask = [ones(1,best_len) zeros(1, n-best_len)];
if size(mask') == size(v)
  mask = mask';
end
errors = find(xor(mask, v));
% fprintf('length = '); disp(best_len);
% fprintf('errors = '); disp(errors);
end