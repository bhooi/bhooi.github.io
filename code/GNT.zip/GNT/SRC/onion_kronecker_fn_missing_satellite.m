function [encoding, encoding_con, Nbits_cum, NelRv_cum] = onion_kronecker_fn_missing_satellite(Data)
%%

%%

n = size(Data,1);
m = size(Data,2);

Data2 = Data;





encoding = [];
encoding_con = [];
Nbits = [];
NelRv = [];
iter = 1;

% v:
% 00 - 'has'
% 01 - 'A-like'
% 10 - 'P-like'

[alli, allj] = find(Data2);

for k = 1:length(alli)
  iii = alli(k);
  jjj = allj(k);

  if iii < n && jjj < m && (sum(sum(Data2(iii:iii+1,jjj:jjj+1)))== 4)

      %% row
  %             cum_i = firstblocksize_i;
  %             cum_j = jjj-1+0;
      cum_i = iii-1;
      cum_j = jjj-1;

      [encoding_row, encoding_con_row, Nbits_row, NelRv_row, Data2_row,iter_row, i_end_flag, j_end_flag] = rowwise_missing_satellite(cum_i, cum_j, Data2, Data,encoding, encoding_con, Nbits, NelRv, iter);

      %% col
  %             cum_i = iii-1+0;
  %             cum_j = firstblocksize_j;

      cum_i = iii-1;
      cum_j = jjj-1;

      [encoding_col, encoding_con_col, Nbits_col, NelRv_col, Data2_col,iter_col, i_end_flag, j_end_flag] = colwise_missing_satellite(cum_i, cum_j, Data2, Data,encoding, encoding_con, Nbits, NelRv, iter);

      %% make decision

  %             if length(encoding_con_row) >= length(encoding_con_col)
      if sum(NelRv_col) >= sum(NelRv_row)
          encoding = encoding_col;
          encoding_con = encoding_con_col;
          Nbits = Nbits_col;
          NelRv = NelRv_col;
          Data2 = Data2_col;
          iter = iter_col;
      else
          encoding = encoding_row;
          encoding_con = encoding_con_row;
          Nbits = Nbits_row;
          NelRv = NelRv_row;
          Data2 = Data2_row;
          iter = iter_row;
      end
      %%%%%% end of previous Onion function
  end
end



%% Left-Overs - DBD
[d1, d2] = find(Data2);
for ii = 1: length(d1)
    [encoding_tmp, encoding_con_tmp, Nbits_cum2_tmp, NelRv_cum2_tmp, Nbits_tmp, NelRv_tmp] = encode_fn_DBD2(d1(ii),d2(ii));
    lencoding = size(encoding,1);
    encoding{lencoding+1,1} = encoding_tmp{1};
    %     encoding{lencoding+2,1} = encoding_tmp{2};
    encoding_con = [encoding_con encoding_con_tmp];
    Nbits = [Nbits Nbits_tmp];
    NelRv = [NelRv NelRv_tmp];
    
    iter = iter + 1; %2;
    Data2(d1(ii), d2(ii)) = 0;
end





%% finalize data

Nbits_cum = cumsum(Nbits);
NelRv_cum = cumsum(NelRv);

% 
% 
% 
% disp(num2str(Nbits_cum(end)));