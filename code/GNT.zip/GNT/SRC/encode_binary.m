function encoded = encode_binary(idx, n)
bin = dec2bin(idx);
leading = repmat('0', 1, ceil(log2(n)) - length(bin));
encoded = sprintf('%s%s', leading, bin);
end