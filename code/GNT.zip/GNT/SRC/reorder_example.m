clear all
close all


% Data = generate_toy_data_kron(); % multi-block matrix example
Data = generate_toy_data_multi_block(); % kronecker matrix example
figure;imagesc(Data);colormap(1-gray);
matrix_reordered = matrix_reorder_fn(Data);


