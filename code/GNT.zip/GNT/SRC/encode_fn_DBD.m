function [encoding, encoding_con, Nbits_cum, NelRv_cum, Nbits, NelRv] = encode_fn_DBD(Data)

encoding_con = [];

n = size(Data,1);
m = size(Data,2);
el_idx = 1;

[alli, allj] = find(Data);

for k = 1:length(alli)
  i = alli(k);
  j = allj(k);

  encoding{el_idx,:} = [elias_code(i) elias_code(j)];
  encoding_con = [encoding_con  encoding{el_idx,:}];

  Nbits(el_idx) = length(encoding{el_idx,:});
  NelRv(el_idx) = 1; % only count elements of 1s in the matrix.

  el_idx = el_idx + 1;
end
            
Nbits_cum = cumsum(Nbits);
NelRv_cum = cumsum(NelRv);