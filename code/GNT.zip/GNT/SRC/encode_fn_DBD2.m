function [encoding, encoding_con, Nbits_cum, NelRv_cum, Nbits, NelRv] = encode_fn_DBD2(i,j)

v = dec2bin(0,2); % DBD property is always 'has'
encoding_con = [];

% n = size(Data,1);
% m = size(Data,2);

el_idx = 1;

% for i = 1: n
%     for j = 1: m
        
%         if Data(i,j) == 1
            
            encoding{el_idx,:} = [elias_code(i) elias_code(j)];
            encoding_con = [encoding_con  encoding{el_idx,:}];
            
            Nbits(el_idx) = length(encoding{el_idx,:});
%             if el_idx == 1
%                 NelRv(el_idx) = (i-1)*m+j;
%             else
%                 NelRv(el_idx) = (i-1)*m+j - sum(NelRv);
%             end
            NelRv(el_idx) = 1; % only count elements of 1s in the matrix.
            
            el_idx = el_idx + 1;
            
%         end
%     end
% end

Nbits_cum = cumsum(Nbits);
NelRv_cum = cumsum(NelRv);