function matrix_reordered = matrix_reorder_fn(Data)

order1 = reorder_chain(Data, 1);
order2 = reorder_chain(Data', 1);
matrix_reordered{1} = Data(order1, order2);
figure;
imagesc(matrix_reordered{1});colormap(1-gray);
print('re-ordered_matrix-chain_method','-dpng');

argIn.data = Data;
argIn.Krange = 2:5;
[matrix_reordered{2}, idx_mapping_row, idx_mapping_col] = encode_fn_block_min(argIn);
figure;
imagesc(matrix_reordered{2});colormap(1-gray);
print('re-ordered_matrix-block_method','-dpng');