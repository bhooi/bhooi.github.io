import numpy as np
from SamplingSet import SamplingSet
from scipy.sparse import coo_matrix
from scipy.sparse import csr_matrix
# @profile
def run_all():
	encoding = []
	Nbits = []
	NelRv = []

	fin = open("../TEMP/Data_chain.csv")
	fout = open("../TEMP/fast_chain_out.csv", 'w')

	num_features = 50;
	num_to_explore = 100;
	[m,n] = [int(x) for x in fin.readline().strip().split(' ')]
	vals = np.array([l.strip().split(" ") for l in fin.readlines()], dtype=int)
	dat = np.array([1]*len(vals))
	coo_dat = coo_matrix((dat, (vals[:, 0]-1, vals[:, 1]-1)), shape=(m,n))
	csr_dat = csr_matrix(coo_dat)
	rand_mat = np.random.randint(2, size=(n, num_features)) * 2 - 1
	features = csr_dat * rand_mat

	# print 'size is ', m, n
	remaining = SamplingSet(range(m))
	# print 'BF remaining len is ', len(remaining)

	rowsums = csr_dat.sum(1)
	start_idx = np.argmax(rowsums)
	start_elems = csr_dat[start_idx, :].toarray()

	cur = start_idx
	# print 'start: %d\n' % (cur,)
	remaining.discard(start_idx)
	# print 'AF remaining len is ', len(remaining)

	ordering = [cur]
	
	while remaining:
		# print 'remaining len is ', len(remaining)
		# print 'ordering len is ', len(ordering)
		cand_idx = remaining.randomSample(min(len(remaining), num_to_explore))
		cand_dist = [sum((features[cur, :] - features[next_idx, :])**2) for next_idx in cand_idx]
		best_idx = cand_idx[cand_dist.index(min(cand_dist))]
		# print 'next: %d with distance %f\n' % (best_idx, min(cand_dist))
		remaining.discard(best_idx)
		ordering.append(best_idx)
		cur = best_idx

	for idx in ordering:	
		fout.write("%d\n" % (idx+1,))

		# num_gained = sum(csr_dat(best_idx, :))
		# enc = ''
		# for j in range(n):
		# 	if csr_dat[cur, j] != csr_dat[best_idx, j]:
		# 		enc += ('1' + encode_binary(j, n))
		# enc += '0'
		# update_enc(encoding, Nbits, NelRv, elem, enc)


run_all()
