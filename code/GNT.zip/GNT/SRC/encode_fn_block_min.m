function [Data_out, idx_mapping_row_out, idx_mapping_col_out] = encode_fn_block_min(argIn)

Data_in = argIn.data;
nEl = sum(sum(Data_in));
Ks = argIn.Krange; 


for K_idx = 1 : length(Ks)
    K = Ks(K_idx);
    disp(['executing now... # of cluster: ' num2str(K)]);
    %% nmf
    [Data, r_id_block_cl, c_id_block_cl, idx_mapping_row, idx_mapping_col] = nmf_processing(Data_in, K);

    %% block diagonalization
    disp('block diag...');
    [Data, idx_mapping_row, idx_mapping_col, r_block_info, c_block_info, diag_score_max, empty_score_max] = block_diag(Data, K, r_id_block_cl, c_id_block_cl, idx_mapping_row, idx_mapping_col);
    
    %%
    Datas{K_idx} = Data;
    idx_mapping_row_all{K_idx} =  idx_mapping_row;
    idx_mapping_col_all{K_idx} =  idx_mapping_col;

    ALOC_alt(K_idx) = empty_score_max + (nEl - diag_score_max);
    disp(['ALOC-alt measure: ' num2str(ALOC_alt(K_idx))]);
end

[~, min_idx] = min(ALOC_alt);
disp(['----------------']);
disp(['final # of cluster: ' num2str(Ks(min_idx))]);
Data_out = Datas{min_idx};
idx_mapping_row_out = idx_mapping_row_all{min_idx};
idx_mapping_col_out = idx_mapping_col_all{min_idx};
