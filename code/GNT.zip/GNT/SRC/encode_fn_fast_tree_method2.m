function [encoding, encoding_con, Nbits_cum, NelRv_cum, Nbits, NelRv] = encode_fn_fast_tree_method2(Data)

if ~issparse(Data)
  Data = sparse(Data);
end

% encode Data and Data' and return the method with better ALOC (with a
% switch bit to encode which we did)
[encoding1, ~, Nbits_cum1, NelRv_cum1, Nbits1, NelRv1] = encode_matrix(Data);
ALOC1 = ALOC_fn(Nbits_cum1, NelRv_cum1);
[encoding2, ~, Nbits_cum2, NelRv_cum2, Nbits2, NelRv2] = encode_matrix(Data');
ALOC2 = ALOC_fn(Nbits_cum2, NelRv_cum2);

if ALOC1 < ALOC2
  encoding = encoding1;
  Nbits = Nbits1;
  NelRv = NelRv1;
  indicator = '0';
else
  encoding = encoding2;
  Nbits = Nbits2;
  NelRv = NelRv2;
  indicator = '1';
end

encoding = [indicator, encoding];
NelRv = [0, NelRv];
Nbits = [1, Nbits];

Nbits_cum = cumsum(Nbits);
NelRv_cum = cumsum(NelRv);
encoding_con = strjoin(encoding, '');
end

function [encoding, encoding_con, Nbits_cum, NelRv_cum, Nbits, NelRv] = encode_matrix(Data)
[m,n] = size(Data);
bin_n_table = generate_binary(ceil(log2(n)));
bin_m_table = generate_binary(ceil(log2(m)));

Tree = fastMST(Data);

[~, first_row] = max(sum(Data, 2));

[disc, pred, ~] = graphtraverse(Tree, first_row, 'Directed', false);
disc_inv = zeros(size(disc));
disc_inv(disc) = 1:m; % inverse permutation of disc


encoding = {};
Nbits = [];
NelRv = [];
el_idx = 1;

% start with root
start_idx = disc(1);

% encode first row index
[el_idx, encoding, Nbits, NelRv] = update_enc(el_idx, encoding, Nbits, NelRv, 0, bin_m_table(:, start_idx)');

enc = sprintf('%s', num2str(Data(start_idx, :), '%d'));
[el_idx, encoding, Nbits, NelRv] = update_enc(el_idx, encoding, Nbits, NelRv, sum(Data(start_idx, :)), enc);
% end
%   
% % termination character
% [el_idx, encoding, Nbits, NelRv] = update_enc(el_idx, encoding, Nbits, NelRv, 0, '0');

tData = Data';
for i = 2:m
  cur = disc(i);
  % encode each difference between cur and anc
  elem = sum(tData(:, cur));
  diffs = find(tData(:, cur) - tData(:, pred(cur)));
  ndiffs = size(diffs, 1);
  enc = sprintf('%s%s', encode_binary(disc_inv(pred(cur)), i-1), elias_code(ndiffs));
  if ndiffs > 0
    diffdiffs = [diffs(1); diff(diffs)];
  end
  for j = 1:size(diffs, 1)
    enc = sprintf('%s%s', enc, elias_code(diffdiffs(j)));
  end
  [el_idx, encoding, Nbits, NelRv] = update_enc(el_idx, encoding, Nbits, NelRv, elem, enc);
end
Nbits_cum = cumsum(Nbits);
NelRv_cum = cumsum(NelRv);
encoding_con = strjoin(encoding, '');

end