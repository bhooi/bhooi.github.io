function [Y, row_c,col_c] = partition_using_nmf(X,K)
%Y is the new matrix
%row_c is the assignment of rows to "blocks"
%col_c is the assignment of columns to "blocks"

[A B] = nnmf(X,K);
row_c = kmeans(A,K);
col_c = kmeans(B',K);
[~,idx_row] = sort(row_c);
[~,idx_col] = sort(col_c);
Y = X(idx_row,idx_col);
