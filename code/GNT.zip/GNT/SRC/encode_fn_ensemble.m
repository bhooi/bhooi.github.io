function [encoding, encoding_con, Nbits_cum, NelRv_cum] = encode_fn_ensemble(Data)

% by default the ensemble includes the onion, fishbone and chain methods.
% The fast tree method is included in this package but requires a
% significant amount of installation of additional packages, so is omitted.
if nargin < 3
  methods = {'Onion', 'Fishbone'};
  fhandles = {@encode_fn_NMF_clustering_fn, @encode_fn_fishbone};
end

Nbits_cum_all = {};
NelRv_cum_all = {};
encoding_all = {};
Nbits_all = {};
NelRv_all = {};

ALOCs = [];

for i=1:length(methods)
  fprintf('%s\n', methods{i});
  [encoding_all{i}, ~, Nbits_cum_all{i}, NelRv_cum_all{i}] = fhandles{i}(Data);
  ALOCs(i) = ALOC_fn(Nbits_cum_all{i}, NelRv_cum_all{i});
end

[~, best] = min(ALOCs);
fprintf(sprintf('Winner: %s\n', methods{best}));
encoding = encoding_all{best};
indicator = encode_binary(best, ceil(log2(length(methods))));

encoding = [indicator, encoding];
NelRv_cum = [0, NelRv_cum_all{best}];
Nbits_cum = [length(indicator), length(indicator) + Nbits_cum_all{best}];
encoding_con = strjoin(encoding, '');
end

% encode an index using binary digits, zero padded to be of fixed length
% ceil(log2(n))
function encoded = encode_binary(idx, n)
bin = dec2bin(idx);
leading = repmat('0', 1, ceil(log2(n)) - length(bin));
encoded = sprintf('%s%s', leading, bin);
end