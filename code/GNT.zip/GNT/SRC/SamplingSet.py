import collections
import random
# credit: http://stackoverflow.com/questions/12587352/python-set-with-the-ability-to-pop-a-random-element

class SamplingSet(collections.MutableSet):
  def __init__(self, initvalue=()):
    self.dic = {}
    self.lst = []
    for x in initvalue: self.add(x)

  def add(self, item):
    if item not in self.dic:
      self.dic[item] = len(self.lst)
      self.lst.append(item)

  def discard(self, item):
    if item in self.dic:
      index = self.dic[item]
      self.lst[index], self.lst[-1] = self.lst[-1], self.lst[index]
      self.dic[self.lst[index]] = index
      del self.lst[-1]
      del self.dic[item]

  def randomSample(self, k):
    if self.lst and len(self.lst) >= k:
      return random.sample(self.lst, k)

  def __iter__(self):
    return iter(self.dic)

  def __len__(self):
    return len(self.dic)

  def __contains__(self, item):
    try:
      return item in self.dic
    except AttributeError:
      return False