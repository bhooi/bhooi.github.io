% given that we encoded elem elements with the encoding enc, update all our
% vectors accordingly
function [el_idx, encoding, Nbits, NelRv] = update_enc(el_idx, encoding, Nbits, NelRv, elem, enc)
NelRv(el_idx) = elem;
encoding{el_idx} = enc;
Nbits(el_idx) = length(encoding{el_idx});
el_idx = el_idx + 1;
end