% run reorder_main

load nell_spmat.txt
Data = spconvert(nell_spmat);
Data = Data(1:1000,:);
data_name = 'NELL';
Nbits_cum = {};
NelRv_cum = {};
ALOCs = [];
methods = {'DBD','Ensemble'};
fhandles = {@encode_fn_DBD, @encode_fn_ensemble};

for i=1:length(methods)
  fprintf('%s\n', methods{i});
  [~, ~, Nbits_cum{i}, NelRv_cum{i}] = fhandles{i}(Data);
  ALOCs(i) = ALOC_fn(Nbits_cum{i}, NelRv_cum{i});
end

colors = [[1 0 0]; [0 0 1]];
figure; hold on;
titles = {'Dot by dot encoding', 'Ensemble encoding'};
for i = 1:length(methods)
  subplot(1, length(methods), i);
  plot([0 Nbits_cum{i}],[0 NelRv_cum{i}],'Color',colors(i,:), 'LineWidth',2);
  subtitle = title(titles{i});
  ylab = ylabel('Elements of matrix received');
  xlab = xlabel('Bits transmitted');
  xlim([0 140000]);
  set(gca,'FontSize', 16);
  set(ylab,'FontSize', 16);
  set(xlab,'FontSize', 16);
  set(subtitle,'FontSize', 20);
end
saveas(gcf,'~/Desktop/tol/hyunahs-code/2015-tol/PLOTS/cj_curves.pdf');
hold off;

% legend(methods, 'Location','southeast');

% figure; hold on;
% hbar = bar(ALOCs); 
% set(gca,'XTick', 1:length(methods), 'XTickLabel',methods);
% colorIndex = 1:length(methods);
% hBarChildren = get(hbar, 'Children');
% set(hBarChildren, 'CData', colorIndex);
% colormap(colors);
% title(sprintf('ALOCs for %s Data', data_name));
% saveas(gcf,sprintf('~/Desktop/tol/hyunahs-code/2015-tol/PLOTS/%s_bar.png', data_name));
% hold off;
