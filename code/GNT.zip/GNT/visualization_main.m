% This is a part of GNT algorithm that re-orders the rows and columns of
% the binary matrix and shows the clusters that minimizes encoding length
% to describe the information in the matrix.
% Put your binary matrix in "Data" variable.
% By selecting the range in "argIn.Krange", you choose the range of the
% number of clusters you want to examine in your matrix. By default, it is
% set to 1:5; the algorithm will try to re-order the matrix to form 1
% cluster to 5 clusters and determine what number of clusters are best
% suited for minimum description.


clear all
close all

addpath ./DATA
addpath ./MISC
addpath ./SRC

% below is the example data we have included.
load DATA/NellData/nell_spmat.txt
Data = spconvert(nell_spmat);
terms_id = fopen('DATA/NellData/nell_terms.txt');
values = textscan(terms_id, '%s', 'delimiter', '\n');
terms = values{1};
values_id = fopen('DATA/NellData/nell_cats.txt');
values = textscan(values_id, '%s', 'delimiter', '\n');
cats = values{1};
terms = terms(1:100);
cats = cats(1:50);
Data = Data(1:100, 1:50);

% if you want to use your data in csv format, please comment above, and
% uncomment below: "filenow" is the name of your .csv data.
% fileID = fopen(filenow,'r');
% formatSpec = '%d %d';
% sizeA = [2 Inf];
% m = fscanf(fileID,formatSpec,sizeA);
% m = m';
% fclose(fileID);
% row_idx = m(:,1)+1; % row and column indices in the txt file starts from 0
% col_idx = m(:,2)+1;
% Data = sparse(row_idx, col_idx, ones(size(m,1),1));

argIn.data = Data;
argIn.Krange = 1:5;
[Data_out, idx_mapping_row, idx_mapping_col] = encode_fn_block_min(argIn);
figure;imagesc(Data_out);colormap(1-gray);


% check!
out = Data(idx_mapping_row, idx_mapping_col);
sum(sum(abs(out - Data_out)))