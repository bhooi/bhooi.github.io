    Education, Learning and Information Theory
    Authors: Bryan Hooi, Hyun Ah Song, Evangelos Papalexakis, and Christos Faloutsos

This software is licensed under Apache License, Version 2.0 (the  "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.


Version: 2.0
Date: Jan 11, 2016
Main Contact: Hyun Ah Song(hyunahs@cs.cmu.edu)





GNT code provides an multi-pronged algorithm for encoding a binary matrix consisting of objects (represented by rows) and properties (represented by columns).
 

The details of PEGASUS can be found in the following paper:

Bryan Hooi, Hyun Ah Song, Evangelos Papalexakis, Rakesh Agrawal, and Christos Faloutsos. "Education, Learning and Information Theory." To appear at The 2015 IEEE ICDM Workshop on Data Mining for Educational Assessment and Feedback.


If you use GNT for research or commercial purposes, please let us know
your institution(company) and whether it's ok to mention it among the users of GNT.

For questions on GNT, please contact <hyunahs@cs.cmu.edu>.

For installation, running, and rebuilding GNT, see the GNT user's guide PDF file.
