%
addpath ./DATA
addpath ./MISC
addpath ./SRC


% Data_blocks = generate_toy_data_block();
% Data_hyper = generate_toy_data_hyperbolic();
Data_kron = generate_toy_data_kron();
Data_names = {'Kronecker'};
methods = {'HyTRA', 'Dot By Dot'};
Datasets = {Data_kron};

fhandles = {@encode_fn_ensemble, @encode_fn_DBD};
ALOCs = zeros(length(Data_names), length(methods));

Nbits_cum = cell(length(Data_names), length(methods));
NelRv_cum = cell(length(Data_names), length(methods));
for j=1:length(Data_names)
  fprintf(sprintf('ON DATASET: %s\n', Data_names{j}));
  for i=1:length(methods)
    fprintf('%s\n', methods{i});
    [~, ~, Nbits_cum{j,i}, NelRv_cum{j,i}] = fhandles{i}(Datasets{j});
    ALOCs(j,i) = ALOC_fn(Nbits_cum{j,i}, NelRv_cum{j,i});
  end
end

% print ALOCs
disp(Data_names);
for i=1:length(methods)
  fprintf('%s  ', methods{i});
  for j=1:length(Data_names)
    fprintf('%d ', ALOCs(j,i));
  end
  fprintf('\n');
end

% plot knowledge curves
for j=1:length(Data_names)
  data_name = Data_names{j};
  figure; hold on;
  title(sprintf('%s Data', data_name));
  xlabel('Bits transferred');
  ylabel('Elements of matrix filled in');

  colors = [[0 0 1]; [1 0 0]; [0 .8 0]; [.5 .5 .7]; [.5 .1 .1]; [.3 1 .3]];
  for i = 1:length(methods)
    plot([0 Nbits_cum{j,i}],[0 NelRv_cum{j,i}],'Color',colors(i,:), 'LineWidth',4);
  end
  set(gca,'FontSize',32);
  set(findall(gcf,'type','text'),'FontSize',32);

  legend(methods, 'Location','southeast');
  hold off; 
end
