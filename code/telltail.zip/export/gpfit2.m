% modified generalized pareto fitting
% x = unique values of data
% w = weights (no. of occurrences)
% k = subgraph size (so k(k-1)/2 is used as max)

function [parmhat,parmci] = gpfit2(x,w,bound,alpha,options)

if ~isvector(x)
    error(message('stats:gpfit:VectorRequired'));
elseif any(x <= 0)
    error(message('stats:gpfit:BadDataPositive'));
end

if nargin < 4 || isempty(alpha)
    alpha = 0.05;
end
if nargin < 5 || isempty(options)
    options = statset('gpfit');
else
    options = statset(statset('gpfit'),options);
end
classX = class(x);
if strcmp(classX,'single')
    x = double(x);
end

n = length(x);
x = sort(x(:));
xmax = x(end);
rangex = range(x);

% Can't make a fit.
if n == 0 || ~isfinite(rangex)
    parmhat = NaN(1,2,classX);
    parmci = NaN(2,2,classX);
    return
elseif rangex < realmin(classX)
    % When all observations are equal, try to return something reasonable.
    if xmax <= sqrt(realmax(classX));
        parmhat = cast([NaN 0],classX);
    else
        parmhat = cast([-Inf Inf]);
    end
    parmci = [parmhat; parmhat];
    return
    % Otherwise the data are ok to fit GP distr, go on.
end

% This initial guess is the method of moments:
xbar = sum(w.*x)/sum(w);
s2 = sum(w.*(x-xbar).^2/(sum(w)-1));
k0 = -.5 .* (xbar.^2 ./ s2 - 1);
sigma0 = .5 .* xbar .* (xbar.^2 ./ s2 + 1);
if k0 < 0 && (xmax >= -sigma0/k0)
    % Method of moments failed, start with an exponential fit
    k0 = 0;
    sigma0 = xbar;
end
parmhat = [k0 sigma0];

% Maximize the log-likelihood with respect to k and lnsigma.
% fprintf('k=%d\n', k);
% disp(parmhat);
% disp(negloglike(parmhat, w, x));
[parmhat,~,err,output] = fmincon(@(a)negloglike(a,w,x),parmhat,[-bound, -1],0,[],[],[],[],[],options);
% parmhat(2) = exp(parmhat(2));

if (err == 0)
    % fminsearch may print its own output text; in any case give something
    % more statistical here, controllable via warning IDs.
    if output.funcCount >= options.MaxFunEvals
        warning(message('stats:gpfit:EvalLimit'));
    else
        warning(message('stats:gpfit:IterLimit'));
    end
elseif (err < 0)
    error(message('stats:gpfit:NoSolution'));
end

tolBnd = options.TolBnd;
atBoundary = false;
if (parmhat(1) < 0) && (xmax > -parmhat(2)/parmhat(1) - tolBnd)
    warning(message('stats:gpfit:ConvergedToBoundary1'));
    atBoundary = true;
elseif (parmhat(1) <= -1/2)
    warning(message('stats:gpfit:ConvergedToBoundary2'));
    atBoundary = true;
end

if nargout > 1
    if ~atBoundary
        probs = [alpha/2; 1-alpha/2];
        [~, acov] = gplike(parmhat, x);
        se = sqrt(diag(acov))';

        % Compute the CI for k using a normal distribution for khat.
        kci = norminv(probs, parmhat(1), se(1));

        % Compute the CI for sigma using a normal approximation for
        % log(sigmahat), and transform back to the original scale.
        % se(log(sigmahat)) is se(sigmahat) / sigmahat.
        lnsigci = norminv(probs, log(parmhat(2)), se(2)./parmhat(2));

        parmci = [kci exp(lnsigci)];
    else
        parmci = [NaN NaN; NaN NaN];
    end
end

if strcmp(classX,'single')
    parmhat = single(parmhat);
    if nargout > 1
        parmci = single(parmci);
    end
end


function nll = negloglike(parms, w, x)
% Negative log-likelihood for the GP (log(sigma) parameterization).
k       = parms(1);
% lnsigma = parms(2);
% sigma   = exp(lnsigma);
sigma = parms(2);
lnsigma = log(sigma);

n = sum(w);
z = x./sigma;

if abs(k) > eps
    if k > 0 || max(z) < -1/k
        % u = 1 + k.*z;
        sumlnu = sum(w.*log1p(k*z)); % sum(log(1+k.*z)
        nll = n*lnsigma + (1+1/k) * sumlnu;
%         if nargout > 1
%             v = z./u;
%             sumv = sum(v);
%             dk = -sumlnu./k^2 + (1+1/k)*sumv;
%             dsigma = (n - (k+1)*sumv)./sigma;
%             ngrad = [dk dsigma*sigma]; % [dL/dk dL/d(lnsigma)]
%         end
    else
        % The support of the GP when k<0 is 0 < x < abs(sigma/k).
        nll = Inf;
%         if nargout > 1
%             ngrad = [-Inf Inf];
%         end
    end
else % limiting exponential dist'n as k->0
    sumz = sum(z);
    % sumzsq = sum(z.^2);
    nll = n*lnsigma + sumz;
%     if nargout > 1
%         dk = -sumzsq/2 + sumz;
%         dsigma = (n - sumz)./sigma;
%         ngrad = [dk dsigma*sigma]; % [dL/dk dL/d(lnsigma)]
%     end
end
