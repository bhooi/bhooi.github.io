function score = metric_tail3(A, x)
n = size(A, 1);
k = sum(x);
if k == 0 || k == n
    score = 0;
else
    s = floor(n/2);
    deg = sum(A)';
    m = sum(deg)/2;

    sumB = sum(deg.^2) / (4*m);
    sumB2 = m + (sum(deg.^2)^2 - sum(deg.^4)) / (8*m^2) - deg'*(A*deg)/(2*m);
    sumBrow2 = sum((deg.^2 / (2*m)).^2);

    p2 = s*(s-1) / (n*(n-1));
    p3 = s*(s-1)*(s-2) / (n*(n-1)*(n-2));
    p4 = s*(s-1)*(s-2)*(s-3) / (n*(n-1)*(n-2)*(n-3));

    Ymean = p2 * sumB;
    wedgesum = (sumBrow2 - 2 * sumB2);
    Ymeansq = p2 * sumB2 + p3 * wedgesum + p4 * (sumB^2 - sumB2 - wedgesum);
    Ystd = sqrt(Ymeansq - Ymean^2);

    adjsum = (x' * A * x ) / 2 - (x' * deg)^2 / (4*m) + x' * deg.^2 / (4*m);
    beta = .9;
    delta = .8;
    score = k^(-delta) * (adjsum - (Ymean + 1.28 * Ystd) * (k / s)^beta);
end

end