function [x, score] = detect_telltail(A)
n = size(A, 1);
M = modularity_matrix(A);

x = rand(n,1) > rand(1,1);
deg = sum(M(x == 1,:))';
score = metric_tail3(A, x);
while 1
    deg_add = deg;
    deg_add(x == 1) = nan;
    deg_del = deg;
    deg_del(x == 0) = nan;
    [~, idx_add] = nanmax(deg_add);
    [~, idx_del] = nanmin(deg_del);
    fprintf('deg_add=%.1f, deg_del=%.1f\n', full(nanmax(deg_add)), full(nanmin(deg_del)));
    x_add = x;
    x_add(idx_add) = 1;
    x_del = x;
    x_del(idx_del) = 0;
    score_add = metric_tail3(A, x_add);
    score_del = metric_tail3(A, x_del);
    if sum(x) == 0
        score_del = -inf;
    end
    if sum(x) == n
        score_add = -inf;
    end
    fprintf('size=%d, edges=%d, score=%.3f, score_add=%.3f, score_del=%.3f ', sum(x), x'*A*x/2, score, score_add, score_del);
    if score >= score_add && score >= score_del
        fprintf('-> local opt\n');
        break
    elseif score_add >= score_del
        fprintf('-> add\n');
        deg = deg + M(:,idx_add);
        x = x_add;
        score = score_add;
    else
        fprintf('-> del\n');
        deg = deg - M(:,idx_del);
        x = x_del;
        score = score_del;
    end
end

end