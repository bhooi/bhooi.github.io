%% GENERATING ERDOS-RENYI GRAPH AND RUNNING METRICS

n = 100; 
A = random_erdos_renyi(n, .5);
x = rand(100, 1) > .5;
score_telltail = metric_tail3(A, x)
[gp_sums, gp_adjsums] = tail_train(A, 200, n);
score_tail = metric_tail(A, x, gp_sums)
score_taildc = metric_adjsums(A, x, gp_adjsums)

%% GENERATING ERDOS-RENYI WITH INJECTED CLIQUE AND USING DETECT_TELLTAIL TO DETECT IT
% (the code for plotting the graph will only work in Matlab2015b and later
% versions. detected nodes are red triangles, undetected are blue circles)

n = 50;% size of graph
m = 20; % size of injected clique
A = random_erdos_renyi(n, .2);
A(1:m, 1:m) = 1;
A = A - diag(diag(A));
G = graph(A);

[x, score] = detect_telltail(A);
fprintf('detected size = %d, edges = %d\n', sum(x), sum(x' * A * x / 2));
fprintf('detected nodes: ');
fprintf('%d ', find(x));
fprintf('\n');

% Requires Matlab2015b or later
% figure('Units', 'pixels', 'Position', [100 100 600 600]);
% h = plot(G,'NodeLabel', {}, 'Layout', 'subspace', 'Dimension', 20, 'MarkerSize',12,'NodeColor', 'blue'); hold on;
% set(gca, 'XTick', [], 'YTick', []);
% highlight(h, find(x),'NodeColor', 'red', 'Marker', '^', 'MarkerSize',13);
% hold off;
% set(gcf, 'PaperPositionMode', 'auto');
% set(gcf,'color','w')
% set(gca,'xcolor','w','ycolor','w','xtick',[],'ytick',[])
% set(gca,'LooseInset',get(gca,'TightInset'));
