function [gp_sums, gp_adjsums] = tail_train(A, num_samples, kmax)
n = size(A, 1);
sample_sums = zeros(kmax, num_samples);
sample_adjsums = zeros(kmax, num_samples);
% sample_cut = zeros(kmax, num_samples);
deg = sum(A);
m = sum(deg)/2;
for sample_idx = 1:num_samples
    if mod(sample_idx, round(num_samples/100)) == 0
        fprintf('.');
    end
    perm = randperm(n);
    S = zeros(n, 1);
    ideg = sparse(zeros(n, 1));
    cur_sum = 0;
    cur_vol = 0;
    for k = 1:kmax
        S(perm(k)) = 1;
        cur_sum = cur_sum + ideg(perm(k));
        cur_vol = cur_vol + deg(perm(k));
        ideg = ideg + A(:, perm(k));
        sample_sums(k, sample_idx) = cur_sum;
        sample_adjsums(k, sample_idx) = cur_sum - cur_vol^2 / (4*m);
%         sample_cut(k, sample_idx) = -(cur_vol - 2*cur_sum) * 2*m / (cur_vol * (2*m - cur_vol));
        sample_cut(k, sample_idx) = 2*cur_sum / cur_vol;
    end
end
fprintf('finished sampling\n');
gp_sums = nan(kmax, 3);
gp_adjsums = nan(kmax, 3);
gp_cut = nan(kmax, 3);
for k = 1:kmax
    if mod(k, round(kmax/100)) == 0
        fprintf('*');
    end
    samp = sample_sums(k, :);
    qtl = quantile(samp, 0.9);
    ce = samp(samp > qtl) - qtl;
    if ~isempty(ce) && max(ce) > 0
        tab = tabulate(ce);
%         gp_sums(k,:) = [qtl gpfit(ce)];
        gp_sums(k,:) = [qtl gpfit2(tab(:,1), tab(:,2), -qtl+k*(k-1)/2)];
    end
    
    samp = sample_adjsums(k, :);
    qtl = quantile(samp, 0.9);
    ce = samp(samp > qtl) - qtl;
    if ~isempty(ce) && max(ce) > 0
        tab = tabulate(ce);
        gp_adjsums(k,:) = [qtl gpfit2(tab(:,1), tab(:,2), -qtl+k*(k-1))];
    end
    
%     samp = sample_cut(k, :);
%     qtl = quantile(samp, 0.9);
%     ce = samp(samp > qtl) - qtl;
%     if ~isempty(ce) && max(ce) > 0
%         tab = tabulate(ce);
%         gp_cut(k,:) = [qtl gpfit2(tab(:,1), tab(:,2), 1)];
%     end
end
fprintf('finished fitting\n');
end