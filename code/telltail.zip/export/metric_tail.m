function score = metric_tail(A, x, gp_params)
edges = x' * A * x / 2;
k = sum(x);
score = tail_score(edges, gp_params(k, :));
end