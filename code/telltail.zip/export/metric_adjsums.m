function score = metric_adjsums(A, x, gp_params)
deg = sum(A);
m = sum(deg)/2;
edges = x' * A * x / 2;
vol = deg * x;
adjsum = edges - vol^2 / (4*m);
k = sum(x);
score = tail_score(adjsum, gp_params(k, :));
end