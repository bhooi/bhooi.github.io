clear all; close all; clc;
cd ~/Desktop/bryan-papers/dense/empirical/code/

rng(10000);

data_name = 'football';
[A, comms, comm_names] = read_twitter(data_name);
A(A > 1) = 1;
n = size(A, 1);

comm_min_size = 10;
filt_comms = comms(cellfun(@length, comms) >= comm_min_size);
kmax = round(.9*n);
[gp_sums, gp_adjsums] = tail_train(A, 5000, kmax);
fprintf('PARAMS:\n');
disp(array2table(gp_sums, 'RowNames', cellstr(num2str((1:kmax)'))));

%%

drawn_per_size = 10000;
num_comms = length(filt_comms);
true_metric_vals = nan(num_comms, 1);
true_block_nodes = nan(num_comms, 1);
true_block_edges = nan(num_comms, 1);
fake_k_step = 10;
fake_k = fake_k_step : fake_k_step : kmax;
num_k = length(fake_k);
quantiles = [.9 .99];
num_quantiles = length(quantiles);
emp_quantiles = nan(num_k, num_quantiles);

fprintf('TRUE COMMUNITIES\n');
comm_sizes = cellfun(@length, filt_comms);
for comm_idx = 1:num_comms
    cur_comm = filt_comms{comm_idx};
    cur_vec = ismember(1:n, cur_comm)';
%     true_metric_vals(comm_idx) = metric_tail(A, cur_vec, gp_sums);
    true_metric_vals(comm_idx) = metric_adjsums(A, cur_vec, gp_adjsums);
    true_block_nodes(comm_idx) = sum(cur_vec);
    true_block_edges(comm_idx) = sum(cur_vec' * A * cur_vec / 2);
end

fprintf('FAKE COMMUNITIES\n');
for k_idx = 1:length(fake_k)
    k = fake_k(k_idx);
    fprintf('k = %d\n', k);
    metric_vals = nan(drawn_per_size, 1);
    for drawn_idx = 1:drawn_per_size
        cur_comm = datasample(1:n, k, 'Replace', false);
        cur_vec = ismember(1:n, cur_comm)';
%         metric_vals(drawn_idx) = metric_tail(A, cur_vec, gp_sums);
        metric_vals(drawn_idx) = metric_adjsums(A, cur_vec, gp_adjsums);
    end
    for quantile_idx = 1:num_quantiles
        emp_quantiles(k_idx, quantile_idx) = quantile(metric_vals, quantiles(quantile_idx));
    end
end
adj_quantiles = (quantiles - 0.9) / 0.1;
%%
rand_per_sz = 100;
rand_sz = nan(rand_per_sz*kmax, 1);
rand_metric = nan(rand_per_sz*kmax, 1);
fprintf('RANDOM COMMUNITIES\n');
cur_idx = 1;
for k = 1:kmax
    for drawn_idx = 1:rand_per_sz
        cur_comm = datasample(1:n, k, 'Replace', false);
        cur_vec = ismember(1:n, cur_comm)';
        rand_sz(cur_idx) = k;
        rand_metric(cur_idx) = metric_adjsums(A, cur_vec, gp_adjsums);
        cur_idx = cur_idx + 1;
    end
end

%%

cols = mycolors(); 
markers = mymarkers();
fig = figure('Units', 'pixels', 'Position', [0 0 500 500]); hold on;
set(gca,'ytick', 0:5:15);
set(gca, 'yticklabel', {'0','1-10^{-5}','1-10^{-10}','1-10^{-15}'});
scatter(true_block_nodes, true_metric_vals, 300, 'red', 'filled', 'Marker', '^'); hold on;
scatter(rand_sz+rand(size(rand_sz)), rand_metric, 6, [.2 .5 1], 'filled', 'Marker', 'o'); hold on;
xlabel('Subgraph size','FontSize',24);
ylabel('Proposed measure','FontSize',24);
ylim([0 15]);
% xlim([0 kmax]);
%     ylim([-inf max(true_metric_vals(:,method_idx)*1.1)]);
% set(findall(fig,'-property','FontSize'),'FontSize',24);
for quantile_idx = 1:num_quantiles
    plot(fake_k, emp_quantiles(:, quantile_idx), 'b-',  'LineWidth', 2, 'MarkerSize', 22);
end

qtlmax = 5; % max theoretical quantile to plot
linecol = [1 1 1]*.7;
for quantile_idx = 1:qtlmax
    plot(get(gca,'xlim'), [quantile_idx quantile_idx], 'k--', 'LineWidth', 2, 'Color', linecol);
    text(125, .3 + quantile_idx, [num2str(100 * (1 - 0.1^quantile_idx)) '%'], 'HorizontalAlignment', 'center','FontWeight','Bold');
end
plot(get(gca,'xlim'), [qtlmax+1 qtlmax+1], 'k--', 'LineWidth', 2, 'Color', linecol);
text(125, .6 + qtlmax+1, '...', 'HorizontalAlignment', 'center');

set(gcf, 'PaperPositionMode', 'auto');
set(findall(gcf,'Type','Axes'),'FontSize',20);
set(findall(gcf,'Type','Text'),'FontSize',20);
set(findall(gcf,'Type','Legend'),'FontSize',20);
set(get(gca,'ylabel'),'FontSize', 24);
set(get(gca,'xlabel'),'FontSize', 24);
printpdf(gcf, sprintf('../plots/quantile4_%s.pdf', data_name),'pdf');
hold off;
% end

