function score = metric_conductance(A, x)
% conductance = -edges across cut / volume of S
deg = sum(A);
score = -(1-x)' * A * x / min(sum(deg(x==1)), sum(deg(x==0)));
end