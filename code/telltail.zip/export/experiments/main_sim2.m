clear all; close all; clc;
cd ~/Desktop/bryan-papers/dense/empirical/code/

num_iters = 50;
data_name = 'arenas-email';
A = read_graph(data_name);
n = size(A, 1);

% density = 10*mean(A(:));
% block_sizes = 10:5:40;
% plot_filename = 'sim2_dense';

density = mean(A(:));
block_sizes = 50:25:200;
plot_filename = 'sim2_sparse';

method_names = {'Tail', 'TailDC', 'TellTail', 'Average', 'Modularity', 'Expansion', 'Conductance', 'Surplus', 'Susp'};
method_switches = [1 1 1 1 1 1 1 1 1];
% method_switches = [0 0 1 1 1 1 1 1 1];
method_names = method_names(method_switches == 1);
num_methods = length(method_names);

num_wrong_blocks = 1000;
num_block_sizes = length(block_sizes);

%%

accuracies = nan(num_block_sizes, num_methods, num_iters);
rescounts = nan(num_block_sizes, num_methods, num_iters);
jaccard = nan(num_block_sizes, num_methods, num_iters);
kmax = round(.9*n);
scores = nan(num_block_sizes, num_iters, num_wrong_blocks + 1, num_methods);

for size_idx = 1:length(block_sizes)
    block_size = block_sizes(size_idx);
    fprintf('PROCESSING BLOCK SIZE: %d\n', block_size);
    for iter_idx = 1:num_iters
        fprintf('Iter: %d\n', iter_idx);
        block = randsample(n, block_size);
        A_inj = A;
        inj = triu(rand(block_size) < density, 1);
        A_inj(block, block) = A(block, block) | (inj + inj');
        x_true = ismember(1:n, block)';
        
        
        x_all = cell(1, num_wrong_blocks + 1);
        x_all{1} = x_true;
        for block_idx = 1:num_wrong_blocks
            block_count = ceil(kmax / num_wrong_blocks * block_idx);
            x_all{block_idx + 1} = ismember(1:n, randsample(n, block_count))';
        end
        
        fprintf('finished generating tests\n');
        [gp_sums, gp_adjsums] = tail_train(A, 1000, kmax);
        method_funcs = {
            @(A, x)metric_tail(A, x, gp_sums), ...
            @(A, x)metric_adjsums(A, x, gp_adjsums), ...
            @metric_tail3, @metric_avdegree, @metric_modularity, @metric_expansion, ...
            @metric_conductance, @metric_excess, @metric_suspiciousness};
        method_funcs = method_funcs(method_switches == 1);
        
        for method_idx = 1:num_methods
            fprintf('Method: %s\n', method_names{method_idx});
            for block_idx = 1:num_wrong_blocks+1
                cur_block = x_all{block_idx};
                scores(size_idx, iter_idx, block_idx, method_idx) = method_funcs{method_idx}(A_inj, cur_block);
            end
            candidates = scores(size_idx, iter_idx, :, method_idx);
            [~, max_idx] = nanmax(candidates + 1e-10 * rand(size(candidates)));
            accuracies(size_idx, method_idx, iter_idx) = (max_idx == 1);
            jaccard(size_idx, method_idx, iter_idx) = sum(x_all{max_idx} & x_true) / sum(x_all{max_idx} | x_true);
            rescounts(size_idx, method_idx, iter_idx) = sum(x_all{max_idx});
        end
    end
end
%%

for size_idx = 1:length(block_sizes)
    
    figure;
    suptitle(sprintf('Empirical size = %d', block_sizes(size_idx)));
    for method_idx = 1:num_methods
        cur_metric = scores(size_idx, 1, :, method_idx);
    %     cur_metric = cur_metric / max(abs(cur_metric));
    %     semilogx(1:size(metric_vals, 1), cur_metric, 'Color', colors(method_idx, :),'LineWidth',2); hold on;
        plotrows = ceil(sqrt(num_methods));
        hh = subplot(plotrows,ceil(num_methods / plotrows),method_idx);
        plot(1:num_wrong_blocks+1, squeeze(cur_metric),'Marker','.'); hold on;
        title(sprintf('%s', method_names{method_idx}));
        axes(hh)
        line(get(hh,'XLim'),[cur_metric(1) cur_metric(1)],'Color',[1 0 0])
    %     axis([-inf,100,-inf,inf])
    end
end

%%

% save('Saved Results/main_sim2_accuracies_saved.mat', 'accuracies');
load Saved' Results'/main_sim2_accuracies_saved.mat
mean_acc = mean(accuracies, 3);
std_acc = std(accuracies, [], 3) / sqrt(num_iters);
% mean_jacc = mean(jaccard, 3);
% mean_rc = mean(rescounts, 3);
fprintf('Exact accuracy: \n');
array2table(mean_acc, 'RowNames', cellstr(num2str(block_sizes(:))), 'VariableNames', method_names)
% fprintf('Jaccard: \n');
% array2table(mean_jacc, 'RowNames', cellstr(num2str(block_sizes(:))), 'VariableNames', method_names)
% fprintf('Timings: \n');
% array2table(timing_means, 'RowNames', cellstr(num2str(block_sizes(:))), 'VariableNames', method_names)
% fprintf('Rescounts: \n');
% array2table(mean_rc, 'RowNames', cellstr(num2str(block_sizes(:))), 'VariableNames', method_names)

%%


colors = mycolors();
figure('Units', 'pixels', 'Position', [100 100 500 500]); hold on;
markers = mymarkers();
for method_idx = 1:num_methods
%     plotrows = ceil(sqrt(num_methods));
%     plot(plotrows,ceil(num_methods / plotrows),method_idx);
    errorbar(block_sizes, mean_acc(:, method_idx), std_acc(:, method_idx), '.-', 'Marker', markers{method_idx}, 'MarkerSize', 12, 'Color', colors(method_idx, :),'LineWidth',3); hold on;
end
data_name_esc = strrep(data_name,'_','\_');
legend(method_names,'Location','southeast');
xlabel('Injected size');
ylabel('Accuracy');
ylim([0 1.02]);
set(findall(gcf,'Type','Axes'),'FontSize',20);
set(findall(gcf,'Type','Text'),'FontSize',24);
set(findall(gcf,'Type','Legend'),'FontSize',20);
set(gcf, 'PaperPositionMode', 'auto');
printpdf(gcf, sprintf('../plots/%s.pdf', plot_filename), 'pdf');
hold off;