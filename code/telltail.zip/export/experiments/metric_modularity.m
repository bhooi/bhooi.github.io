function score = metric_modularity(A, x)
% modularity = number of edges - expected number of edges
deg = sum(A);
m = sum(deg) / 2;
score = (x' * A * x - sum(deg(x==1))^2 / (2*m))/m;
end