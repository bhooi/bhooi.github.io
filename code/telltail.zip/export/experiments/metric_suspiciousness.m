function score = metric_suspiciousness(A, x)
% conductance = n(p - rho + rho log (rho/p)), where p = ambient fraction
% and rho = block fraction
n = length(x);
s = sum(x);
p = sum(A(:)) / n^2;
rho = sum(x' * A * x) / s^2;
score = s^2 * (p - rho + rho * log(rho / p));
end