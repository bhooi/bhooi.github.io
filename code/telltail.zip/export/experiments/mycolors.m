function col = mycolors()
% addpath distinguishable_colors/
% col(1:3,:) = [.3 .3 1; 0 0 .5; .2 1 1];
% other_col = distinguishable_colors(n-2);
% col(4:n,:) = other_col(2:end,:);
bluecol = [.3 .3 1; 0 0 .5; .2 1 1];
othercol = [1 0 0; 0 1 0; 1 .2 .8; 1 .6 0; 0 .5 0; 1 .5 .5];
col = [bluecol; othercol];
end