function [x, score] = detect_avdegree(A)
[x, score] = local_greedy_with_metric(A, @metric_avdegree);
end