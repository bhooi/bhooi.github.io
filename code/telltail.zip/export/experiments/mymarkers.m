function markers = mymarkers()
markers = {'x', 'o', '*', '+', 'diamond', 'square', 'v', '^', '>', '<', 'p', 'h'};
end