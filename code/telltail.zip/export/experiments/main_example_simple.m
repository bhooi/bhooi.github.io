clear all; close all; clc;
cd ~/Desktop/bryan-papers/dense/empirical/code/
addpath distinguishable_colors/

% myseed = randi(1000,1,1);
myseed = 88;
rng(myseed);

plot_type = 'pdf';
num_trials = 10;
graph_layout_type = 'subspace';

colors = distinguishable_colors(5);
n = 50;
m = 10;
A = random_erdos_renyi(n, .2);
A(1:m, 1:m) = 1;
A = A - diag(diag(A));
G = graph(A);
truth = [ones(1, m) zeros(1, n-m)]';

% PLOT BEST DETECTED GROUPS FOR MODULARITY VS OURS
method_names = {'TellTail', 'AveDegree', 'Modularity'};
method_funcs = {@detect_telltail, @detect_avdegree, @detect_modularity};
num_methods = length(method_names);
for method_idx = 1:num_methods
    fprintf('Method: %s\n', method_names{method_idx});
    x_all = cell(1, num_trials);
    score_all = nan(1, num_trials); 
    for trial_idx = 1:num_trials
        [x, score] = method_funcs{method_idx}(A);
        x_all{trial_idx} = x; 
        score_all(trial_idx) = score;
        fprintf('trial %d: size=%d, sum=%d, score=%.3f\n', trial_idx, sum(x), sum(x' * A * x / 2), score);
    end
    [best_val, best_idx] = max(score_all);
    x_best = x_all{best_idx};
    if method_idx == 3
        x_best = 1 - x_best;
    end
    
    figure('Units', 'pixels', 'Position', [100 100 600 600]);
    h = plot(G,'NodeLabel', {}, 'Layout', graph_layout_type, 'Dimension', 20, 'MarkerSize',12,'NodeColor', colors(1, :)); hold on;
    set(gca, 'XTick', [], 'YTick', []);
    highlight(h, find(x_best),'NodeColor', colors(2, :), 'Marker', '^', 'MarkerSize',13);
%     highlight(h, find(~x_best & truth),'NodeColor', colors(1, :), 'Marker', 's', 'MarkerSize',8);
%     highlight(h, find(x_best & truth),'NodeColor', colors(2, :), 'Marker', 's', 'MarkerSize',8);
    fprintf('detected size = %d, edges = %d\n', sum(x_best), sum(x_best' * A * x_best / 2));
    hold off;
    set(gcf, 'PaperPositionMode', 'auto');
    set(gcf,'color','w')
    set(gca,'xcolor','w','ycolor','w','xtick',[],'ytick',[])
    set(gca,'LooseInset',get(gca,'TightInset'));
    printpdf(gcf, sprintf('../plots/graph_plots_simple_circle/%s_%s.%s', graph_layout_type, method_names{method_idx}, plot_type), plot_type); 
end

fprintf('SEED = %d\n', myseed);
