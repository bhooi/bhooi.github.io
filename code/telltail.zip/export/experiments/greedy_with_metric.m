function x_best = greedy_with_metric(A, metric)
n = size(A,1);
x = ones(n,1);
deg = sum(A(x==1, x==1));
x_best = nan(n,1);
score_best = -Inf;
for iter_idx = 1:n
    score = metric(A, x);
    [~, i] = min(deg);
    x(i) = 0;
    deg(i) = inf;
    deg = deg - A(i,:);
    if score >= score_best
        score_best = score;
        x_best = x;
    end
    fprintf('k=%d, score=%.1f\n', sum(x), score);
end
end