function [A, comms, comm_names] = read_twitter(data_name)
ids_file = fopen(sprintf('../data_ground/twitter/%s/%s.ids', data_name, data_name));
ids = textscan(ids_file, '%s');
ids = ids{1};
idmap = containers.Map;
for i = 1:length(ids)
    idmap(ids{i}) = i;
end
n = length(idmap);

network_file = fopen(sprintf('../data_ground/twitter/%s/%s-follows.mtx', data_name, data_name));
textscan(network_file, '%d %d %d', 1);
E = textscan(network_file, '%s %s 1');
m = length(E{1});

A = zeros(n, n);
for i = 1:m
    A(idmap(E{1}{i}), idmap(E{2}{i})) = 1;
end
A = sparse(A);
A = A + A';

comms_file = fopen(sprintf('../data_ground/twitter/%s/%s.communities', data_name, data_name));
comms_split = textscan(comms_file, '%s', 'delimiter', '\n');
num_comms = length(comms_split{1});
comm_names = cell(num_comms, 1);
comms = cell(num_comms, 1);
for i = 1:num_comms
  line_split = strsplit(comms_split{1}{i});
  comm_names{i} = line_split{1}(1:end-1);
  comm_str = strsplit(line_split{2},',');
  comms{i} = cellfun(@(x)idmap(x), comm_str);
end
end