function score = metric_avdegree(M, x)
if sum(x) == 0
    score = 0;
else
    score = x' * M * x / (2 * sum(x));
end
end