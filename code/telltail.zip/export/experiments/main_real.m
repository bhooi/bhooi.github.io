clear all; close all; clc;
cd ~/Desktop/bryan-papers/dense/empirical/code/
addpath distinguishable_colors/

method_names = {'tail', 'tail2', 'tail3', 'avdegree', 'modularity', 'expansion', 'conductance', 'excess', 'suspiciousness'};
method_switches = [1 1 1 1 1 1 1 1 1];
method_names = method_names(method_switches == 1);
num_methods = length(method_names);
data_names = {'football', 'olympics', 'politicsie', 'politicsuk', 'rugby'};
num_datasets = length(data_names);

auc = nan(num_datasets, num_methods);
avprec = nan(num_datasets, num_methods);

for data_idx = 1:length(data_names)
    
    data_name = data_names{data_idx};
    [A, comms, comm_names] = read_twitter(data_name);
    A(A > 1) = 1;
    n = size(A, 1);

    % save(cache_path, 'A', 'comms');
    % load(cache_path);
    % fprintf('finished loading data\n');
    % subset_idx = 1:200000;
    % A = A(subset_idx, subset_idx);
    % good_idx = find(sum(A) > 10);
    % A = A(good_idx, good_idx);
    % subset_idx = subset_idx(good_idx); % keep track of original identities of rows in A

    comm_min_size = 4;
    true_comms = comms(cellfun(@length, comms) >= comm_min_size);
    filt_comms = {};
    for comm_idx = 1:length(true_comms)
        cur_comm = comms{comm_idx};
    %     cur_comm = intersect(cur_comm, good_idx);
        if length(cur_comm) >= comm_min_size
            filt_comms{length(filt_comms)+1} = cur_comm;
        end
    end
    fprintf('finished filtering\n');

    kmax = round(.95*n);
    [gp_sums, gp_adjsums] = tail_train(A, 10000, kmax);
    fprintf('finished fitting GP parameters\n');

    good_idx = 1:n;
    drawn_per_fake = 200;
    chosen_per_size = 2;
    num_wrong_blocks = kmax * chosen_per_size;
    num_comms = length(filt_comms);

    method_funcs = {
        @(A, x)metric_tail(A, x, gp_sums), ...
        @(A, x)metric_adjsums(A, x, gp_adjsums), ...
        @metric_tail3, @metric_avdegree, @metric_modularity, @metric_expansion, ...
        @metric_conductance, @metric_excess, @metric_suspiciousness};
    method_funcs = method_funcs(method_switches == 1);
    metric_vals = nan(num_comms + num_wrong_blocks, num_methods);

    true_block_nodes = nan(num_comms, 1);
    true_block_edges = nan(num_comms, 1);
    fake_block_nodes = nan(num_wrong_blocks, 1);
    fake_block_edges = nan(num_wrong_blocks, 1);

    fprintf('TRUE COMMUNITIES\n');
    for comm_idx = 1:num_comms
        cur_comm = filt_comms{comm_idx};
        cur_vec = ismember(good_idx, cur_comm)';
        for method_idx = 1:num_methods
            metric_vals(comm_idx, method_idx) = method_funcs{method_idx}(A, cur_vec);
        end
        true_block_nodes(comm_idx) = sum(cur_vec);
        true_block_edges(comm_idx) = cur_vec' * A * cur_vec / 2;
    end

    fprintf('FAKE COMMUNITIES\n');
    comm_sizes = cellfun(@length, filt_comms);
    comm_idx = 1;
    for k = 1:kmax
        fprintf('k = %d\n', k);
        for chosen_idx = 1:chosen_per_size
            draws = cell(1,drawn_per_fake);
            edge_counts = nan(1, drawn_per_fake);
            for drawn_idx = 1:drawn_per_fake
                cur_comm = datasample(good_idx, k, 'Replace', false);
                cur_vec = ismember(good_idx, cur_comm)';
                draws{drawn_idx} = cur_vec;
                edge_counts(drawn_idx) = cur_vec' * A * cur_vec / 2;
            end
            [~, max_idx] = max(edge_counts);
    %         fprintf('mean = %.3f; drawn = %d\n', mean(edge_counts), edge_counts(max_idx));

            for method_idx = 1:num_methods
                metric_vals(num_comms+comm_idx, method_idx) = method_funcs{method_idx}(A, draws{max_idx});
            end
            fake_block_nodes(comm_idx) = sum(cur_vec);
            fake_block_edges(comm_idx) = cur_vec' * A * cur_vec / 2;
            comm_idx = comm_idx + 1;
        end
    end
    
    for method_idx = 1:num_methods
        labels = [ones(1, num_comms) zeros(1, num_wrong_blocks)];
        [~,~,~,auc(data_idx, method_idx)] = perfcurve(labels, metric_vals(:, method_idx)', 1);
        prec = precision_curve(metric_vals(:, method_idx), labels);
        avprec(data_idx, method_idx) = mean(prec);
    end
    
    figure;
    colors = distinguishable_colors(num_methods);
    for method_idx = 1:num_methods
        cur_metric = metric_vals(:, method_idx);
    %     cur_metric = cur_metric / max(abs(cur_metric));
    %     semilogx(1:size(metric_vals, 1), cur_metric, 'Color', colors(method_idx, :),'LineWidth',2); hold on;
        hh = subplot(3,3,method_idx);
        semilogx(1:size(metric_vals, 1), cur_metric,'Marker','.'); hold on;
        title(sprintf('%s: AUC %.2f AP %.2f', method_names{method_idx}, auc(data_idx, method_idx), avprec(data_idx, method_idx)));
        axes(hh)
        line([num_comms num_comms],get(hh,'YLim'),'Color',[1 0 0])
    %     axis([-inf,100,-inf,inf])
    end
    saveas(gcf, sprintf('../plots/accreal_%s.png', data_name));
    hold off;
end

fprintf('AUC: \n');
array2table(auc, 'RowNames', data_names, 'VariableNames', method_names)
fprintf('AvPrec: \n');
array2table(avprec, 'RowNames', data_names, 'VariableNames', method_names)
input.data = avprec;
input.tableColLabels = method_names;
input.tableRowLabels = {'Football','Olympics','Politics IE','Politics UK','Rugby'};
input.dataFormat = {'%.2f',length(input.tableColLabels)};
input.booktabs = 1;
input.transposeTable = 0;
latex = latexTable(input);
