clear all; close all; clc;
cd ~/Desktop/bryan-papers/dense/empirical/code
addpath distinguishable_colors/
addpath powerlaw/
addpath kronecker/
addpath matlab_bgl/
addpath evim/

num_samples = 10000;
num_subset_sizes = 9;

Dataset_names = {'topology', 'opsahl-ucforum','arenas-meta', 'opsahl-ucsocial', 'arenas-email','moreno_blogs', 'petster-hamster',...
    'arenas-pgp','dblp-cite'};
Dataset_displaynames = {'InternetAS', 'UCForum','Meta', 'UCSocial', 'Email','Blogs','Petster','PGP','DBLP'};
Dataset_switches = [1 0 0 0 0 0 0 0 0];
% Dataset_switches = ones(1, length(Dataset_names));
Dataset_names = Dataset_names(Dataset_switches == 1);
num_datasets = length(Dataset_names);

sample_sums = nan(num_datasets, num_subset_sizes, num_samples); 
sample_vols = nan(num_datasets, num_subset_sizes, num_samples);

dataset_sizes = nan(num_datasets, 1);
dataset_mass = nan(num_datasets, 1);
sample_sizes = nan(num_datasets, num_subset_sizes);
colors = distinguishable_colors(5);

for data_idx = 1:num_datasets
    data_name = Dataset_names{data_idx};
    A = read_graph(data_name);
    n = size(A, 1);
    
    fprintf('DATASET: %s (size %d)\n', Dataset_names{data_idx}, n);
    dataset_sizes(data_idx) = n;
    dataset_mass(data_idx) = sum(A(:)/2);
    sizes_lower = max(30, sqrt(n));
    sizes_upper = n/2;
    sample_sizes(data_idx, :) = [round(logspace(log10(sizes_lower), log10(sizes_upper), num_subset_sizes))];
%     sample_sizes(data_idx, :) = [round(linspace(30, 200, num_subset_sizes))];
%     sample_sizes(data_idx, :) = [round(logspace(log10(20), log10(100), num_subset_sizes/2)) round(logspace(log10(200), log10(n/3), num_subset_sizes/2))];

    deg = sum(A, 1)';
    num_edges = sum(deg) / 2;
    m = sum(deg)/2;
%     M = A - deg * deg' / (2 * m);
%     Mz = M - diag(diag(M));
    for s_idx = 1:num_subset_sizes
        fprintf('s_idx: %d\n', s_idx);
        for sample_idx = 1:num_samples
            k = sample_sizes(data_idx, s_idx);
            S = randsample(n, k);
            x = ismember(1:n, S)';
            A_S = A(S,S);
            d_S = deg .* x;
%             sample_sums(data_idx, s_idx, sample_idx) = (sum(A_S(:))) / 2;
            sample_sums(data_idx, s_idx, sample_idx) = (x' * A * x) / 2 - (sum(d_S)^2 - sum(d_S.^2)) / (4*m);
%             sample_vols(data_idx, s_idx, sample_idx) = sum(deg(S));
        end  
    end
end

%% Plot: subgraph density plots
num_fits = 200;
fraction_fit = 0.3;
cutoffs = .9;
num_cutoffs = length(cutoffs);
gp_param = nan(num_datasets, num_subset_sizes, num_fits, num_cutoffs, 3);
for data_idx = 1:num_datasets
    m = dataset_mass(data_idx);
    for cutoff_idx = 1:num_cutoffs
        gp_cutoff = cutoffs(cutoff_idx);
        data_name = Dataset_names{data_idx};
%         figure;
%         data_name_esc = strrep(data_name,'_','\_');
%         suptitle(sprintf('%s (n=%d)', data_name_esc, dataset_sizes(data_idx)));
        for s_idx = 1:num_subset_sizes
            nrow = ceil(sqrt(num_subset_sizes));
            subplot(nrow,ceil(num_subset_sizes / nrow), s_idx);

            cur_sum = squeeze(sample_sums(data_idx, s_idx, :));
            obs = cur_sum;
            for fit_idx = 1:num_fits
                obs_samp = randsample(obs, fraction_fit * length(obs));
                qtl = quantile(obs_samp, gp_cutoff);
                ce = obs_samp(obs_samp > qtl) - qtl;
                if ~isempty(ce) && max(ce) > 0
                    gp_param(data_idx, s_idx, fit_idx, cutoff_idx, :) = [qtl gpfit(ce)];
                end
            end

%             [ycdf,xcdf] = cdfcalc(obs);
%             plot_cmd = @semilogy;
%             plot_cmd(xcdf, 1-ycdf(2:end), 'Color', colors(1, :),'LineWidth',2); hold on;

%             qtl = quantile(obs, gp_cutoff);
%             ce = obs(obs > qtl) - qtl;
%             if ~isempty(ce) && max(ce) > 0
%                 gp_full = [qtl gpfit(ce)];
%             end
%             gpcdf = 1 - cdf(pfit, xcdf);
%             plot_cmd(xcdf, gpcdf, '--','LineWidth', 2, 'Color', colors(2,:)); hold on;
%             title(sprintf('k = %d, GP(%.2f, %.2f, %.2f)', sample_sizes(data_idx, s_idx), gp_full(1), gp_full(2), gp_full(3)));
        end
        hold off;
    end
end

%%
gp_param_mean = reshape(mean(gp_param, 3), num_datasets, num_subset_sizes, num_cutoffs, 3);
gp_param_sd = reshape(std(gp_param, [], 3), num_datasets, num_subset_sizes, num_cutoffs, 3);
lm_mu_fits = nan(num_datasets, num_cutoffs, 3);
lm_sigma_fits = nan(num_datasets, num_cutoffs, 3);
xzi_fits = nan(num_datasets, num_cutoffs);
% disp(array2table(gp_param_mean, 'RowNames', Dataset_names));

for data_idx = 1:num_datasets
    for cutoff_idx = 1:num_cutoffs
        data_name = Dataset_names{data_idx};
        m = dataset_mass(data_idx);
        n = dataset_sizes(data_idx);
        
        xzi = nan(1, num_subset_sizes);
        xzi_err = nan(1, num_subset_sizes);
        sigma = nan(1, num_subset_sizes);
        mu = nan(1, num_subset_sizes);
        for s_idx = 1:num_subset_sizes
            param = gp_param_mean(data_idx, s_idx, cutoff_idx, :);
            if ~isempty(param) && ~any(isnan(param))
                mu(s_idx) = param(1);
                xzi(s_idx) = param(2);
                sigma(s_idx) = param(3);
                xzi_err(s_idx) = 2*gp_param_sd(data_idx, s_idx, cutoff_idx, 2) / sqrt(num_fits);
            end
        end

        cur_sizes = sample_sizes(data_idx, :);
        notnan = ~isnan(log(mu));
        lm1 = fitlm(log(cur_sizes(notnan)), log(mu(notnan)));
        coef1 = lm1.Coefficients.Estimate;
        lm_mu_fits(data_idx, cutoff_idx, 1:2) = coef1;
        lm_mu_fits(data_idx, cutoff_idx, 3) = lm1.Rsquared.Ordinary;
        xzi_fits(data_idx, cutoff_idx) = mean(xzi);
        lm3 = fitlm(log(cur_sizes), log(sigma));
        coef3 = lm3.Coefficients.Estimate;
        lm_sigma_fits(data_idx, cutoff_idx, 1:2) = coef3;
        lm_sigma_fits(data_idx, cutoff_idx, 3) = lm3.Rsquared.Ordinary;

        cur_sizes = cur_sizes(1:end-1);
        mu = mu(1:end-1);
        sigma = sigma(1:end-1);
        
        figure('Units', 'pixels', 'Position', [100 100 650 300]); hold on;
        set(gcf, 'PaperPositionMode', 'auto');
        subplot(1,2,1); plot(cur_sizes, mu, 'x', 'Color', colors(1,:),'MarkerSize', 16,'LineWidth',3); hold on;
        xlabel('$k$','Interpreter','latex'); 
        ylabel('$ \mu(k) $','Interpreter','latex');
        plot(cur_sizes, exp(coef1(2) * log(cur_sizes) + coef1(1)), 'Color', colors(1,:),'LineWidth',3);
%         plot(cur_sizes, cur_sizes.^2 * m / n^2, 'Color', colors(4,:)); hold on;
%         plot(cur_sizes, cur_sizes.^2 * m / n^2 + 1.28 * cur_sizes * sqrt(m) / n, 'Color', colors(5,:)); hold on;
        set(gca,'xscale','log'); set(gca,'yscale','log');
%         title(sprintf('%s: $ \\mu $', Dataset_displaynames{data_idx}),'Interpreter','latex');
        
        subplot(1,2,2); plot(cur_sizes, sigma, 'x', 'Color', colors(2,:),'MarkerSize', 16,'LineWidth',3); hold on;
        xlabel('$k$','Interpreter','latex'); 
        ylabel('$ \sigma(k) $','Interpreter','latex');
        set(gca,'xscale','log'); set(gca,'yscale','log');
        plot(cur_sizes, exp(coef3(2) * log(cur_sizes) + coef3(1)), 'Color', colors(2,:),'LineWidth',3); hold on;
%         title(sprintf('%s: $ \\sigma $', Dataset_displaynames{data_idx}),'Interpreter','latex');
        fig=gcf;
        set(findall(gcf,'Type','Axes'),'FontSize',20);
        set(findall(gcf,'Type','Text'),'FontSize',24);
        set(findall(gcf,'Type','Legend'),'FontSize',20);
        printpdf(gcf, sprintf('../plots/gpparam_%s.pdf', Dataset_names{data_idx}), 'pdf');
        hold off;
    end
end

%%

disp(array2table(squeeze(lm_mu_fits(:, 1, 2:3)), 'RowNames', Dataset_names, 'VariableNames', {'Slope', 'R2'}));
mean(lm_mu_fits(:, 1, 2))
disp(array2table(squeeze(lm_sigma_fits(:, 1, 2:3)), 'RowNames', Dataset_names, 'VariableNames', {'Slope', 'R2'}));
mean(lm_sigma_fits(:, 1, 2))
disp(array2table(xzi_fits(:, 1), 'RowNames', Dataset_names, 'VariableNames', {'Xzi'}));

input.data = [squeeze(lm_mu_fits(:, 1, 2:3)) squeeze(lm_sigma_fits(:, 1, 2:3)) xzi_fits(:, 1)];
input.tableColLabels = {'$\mu$ Slope','$R^2$','$\sigma$ Slope', '$R^2$', '$\xi$'};
input.tableRowLabels = Dataset_displaynames;
input.dataFormat = {'%.2f',5};
input.booktabs = 1;
latex = latexTable(input);
 
%% COMPARE ACROSS CUTOFFS

% figure; hold on;
% for cutoff_idx = 1:num_cutoffs
%     cur_sizes = sample_sizes(data_idx, :);
%     coef0 = lm_mu_fits(1, cutoff_idx, :);
%     plot(log(cur_sizes), coef0(2) * log(cur_sizes) + coef0(1), 'Color', colors(3,:)); hold on;
% end
% hold off;

% figure; hold on;
% subplot(1,2,1);
% plot(log(1-cutoffs), lm_mu_fits(1,:,1), 'r-x'); title('mu coeff');
% subplot(1,2,2);
% plot(log(1-cutoffs), lm_mu_fits(1,:,2), 'b-x'); title('mu slope');
% hold off;

%% Mean Excess plots

% for data_idx = 1:num_datasets
%     data_name = Dataset_names{data_idx};
%     figure;
%     data_name_esc = strrep(data_name,'_','\_');
%     suptitle(sprintf('%s (n=%d)', data_name_esc, dataset_sizes(data_idx)));
%     colors = distinguishable_colors(num_models+1);
%     for s_idx = 1:num_subset_sizes
%         nrow = ceil(sqrt(num_subset_sizes));
%         subplot(nrow,ceil(num_subset_sizes / nrow), s_idx);
%         samples = sample_sums{data_idx, 1}; % samples from actual data
%         meplot(samples(s_idx, :));
%         title(sprintf('k = %d', sample_sizes(data_idx, s_idx)));
%         legend(model_names,'Location','northeast');
%     end
%     saveas(gcf, sprintf('../plots/meplot_%s.png', data_name));
%     hold off;
% end