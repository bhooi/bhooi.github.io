function [x, score] = detect_modularity(A)
M = modularity_matrix(A);
[x, score] = local_greedy_with_metric(M, @metric_matrixsum);
end