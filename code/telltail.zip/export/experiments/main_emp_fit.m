clear all; close all; clc;
cd ~/Desktop/bryan-papers/dense/empirical/code
addpath distinguishable_colors/
addpath powerlaw/
addpath kronecker/
addpath matlab_bgl/
addpath evim/

num_samples = 1000;
num_subset_sizes = 1;
gp_cutoff = 0.9;

Dataset_names = {'arenas-jazz', 'contact', 'opsahl-ucforum','arenas-meta', 'moreno_propro', 'opsahl-ucsocial',...
    'opsahl-powergrid','moreno_blogs','petster-hamster','subelj_cora','dblp-cite', 'ca-AstroPh',...
    'cit-HepTh', 'topology','facebook-wosn-wall'};
Dataset_switches = [0,0,1,0,0,0,0,0,0,0,0,0,0,0,0];
Dataset_names = Dataset_names(Dataset_switches == 1);
num_datasets = length(Dataset_names);

sample_sums = zeros(num_datasets, num_subset_sizes, num_samples);
sample_sums2 = zeros(num_datasets, num_subset_sizes, num_samples);

dataset_sizes = nan(num_datasets);
dataset_mass = nan(num_datasets);
sample_sizes = nan(num_datasets, num_subset_sizes);

for data_idx = 1:num_datasets
    data_name = Dataset_names{data_idx};
    A = read_graph(data_name);
    n = size(A, 1);
    
    fprintf('DATASET: %s (size %d)\n', Dataset_names{data_idx}, n);
    dataset_sizes(data_idx) = n;
    dataset_mass(data_idx) = sum(A(:)/2);
    sample_sizes(data_idx, :) = [round(linspace(n/30, n/3, num_subset_sizes))];
    deg = sum(A, 1)';
    m = sum(deg)/2;
    M = A - deg * deg' / (2 * m);
    Mz = M - diag(diag(M));
    for s_idx = 1:num_subset_sizes
        fprintf('s_idx: %d\n', s_idx);
        for sample_idx = 1:num_samples
            k = sample_sizes(data_idx, s_idx);
            S = randsample(n, k);
            A_S = A(S,S);
            M_S = Mz(S,S);
            sample_sums(data_idx, s_idx, sample_idx) = sum(A_S(:)) / 2;
            sample_sums2(data_idx, s_idx, sample_idx) = sum(M_S(:)) / 2;
        end
    end
end

%%
% 
% mean_sums2 = mean(sample_sums2, 3);
% std_sums2 = std(sample_sums2, [], 3);
% 
% 


%% Plot: subgraph density plots

plot_cmd = @loglog;
gp_param = cell(num_datasets, num_subset_sizes);
for data_idx = 1:num_datasets
    data_name = Dataset_names{data_idx};
    figure;
    set(gca,'YScale','log');
    data_name_esc = strrep(data_name,'_','\_');
    suptitle(sprintf('%s (n=%d)', data_name_esc, dataset_sizes(data_idx)));
    colors = distinguishable_colors(5);
    for s_idx = 1:num_subset_sizes
        nrow = ceil(sqrt(num_subset_sizes));
        subplot(nrow,ceil(num_subset_sizes / nrow), s_idx);
        
        samp = squeeze(sample_sums(data_idx, s_idx, :));
        [ycdf,xcdf] = cdfcalc(samp);
        plot_cmd(xcdf, 1-ycdf(2:end), 'Color', 'k','LineWidth',2); hold on;
        if ~all(sum(samp) == 0)
            pfit = paretotails(samp,0,gp_cutoff); 
            gp_param{data_idx, s_idx} = [quantile(samp, gp_cutoff) upperparams(pfit)];
            gpcdf = 1 - cdf(pfit, xcdf);
            plot_cmd(xcdf, gpcdf, '--','LineWidth', 2, 'Color', [1 0 0]); hold on;

            title(sprintf('k = %d', sample_sizes(data_idx, s_idx)));
        end
        n = dataset_sizes(data_idx);
        s = sample_sizes(data_idx, s_idx);
        dens = dataset_mass(data_idx) / (n * (n-1) / 2);
        block_mean = dens * s * (s-1) / 2;
        pcdf = 1 - poisscdf(xcdf, block_mean);
        plot_cmd(xcdf, 1-ycdf(2:end), 'Color', colors(1, :),'LineWidth',2); hold on;
%             if s_idx == num_subset_sizes
%                 legend(model_names,'Location','northeast');
%             end
    end
%     saveas(gcf, sprintf('../plots/emp_%s.png', data_name));
    hold off;
end

% disp(cell2table(gp_param, 'RowNames', Dataset_names));

% %% Plotting GP parameters
% for data_idx = 1:num_datasets
%     xzi = nan(1, num_subset_sizes);
%     sigma = nan(1, num_subset_sizes);
%     mu = nan(1, num_subset_sizes);
%     for s_idx = 1:num_subset_sizes
%         param = gp_param{data_idx, s_idx};
%         if ~isempty(param) && ~any(isnan(param))
%             mu(s_idx) = param(1);
%             xzi(s_idx) = param(2);
%             sigma(s_idx) = param(3);
%         end
%     end
%     figure; 
%     subplot(1,3,1); semilogy(1:num_subset_sizes, mu, 'c-x');
%     title(sprintf('%s: mu\n', Dataset_names{data_idx}));
%     subplot(1,3,2); plot(1:num_subset_sizes, xzi, 'r-x');
%     title(sprintf('%s: xzi\n', Dataset_names{data_idx}));
%     subplot(1,3,3); semilogy(1:num_subset_sizes, sigma, 'b-x');
%     title(sprintf('%s: sigma\n', Dataset_names{data_idx}));
% %     saveas(gcf, sprintf('../plots/gpparam_%s.png', Dataset_names{data_idx}));
%     hold off;
% end

