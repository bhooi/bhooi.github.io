function score = metric_excess(A, x)
x_count = sum(x);
score = x' * A * x - 1/3 * x_count * (x_count-1) / 2;
end