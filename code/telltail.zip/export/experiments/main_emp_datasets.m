% EMPIRICAL FINDINGS FOR GP DISTRIBUTIONS VS POISSON / GAUSSIAN FIT TO
% EMPIRICAL SUBGRAPH DENSITY PLOTS, COMPARING ACROSS DATASETS

clear all; close all; clc;
cd ~/Desktop/bryan-papers/dense/empirical/code
addpath distinguishable_colors/
addpath powerlaw/

num_samples = 5000;
num_subset_sizes = 1;
gp_cutoff = 0.9;

Dataset_names = {'opsahl-ucforum','moreno_blogs','topology'};
Dataset_displaynames = {'UCForum','Blogs','InternetAS'};
Dataset_switches = [0 0 1];
Dataset_names = Dataset_names(Dataset_switches == 1);
Dataset_displaynames = Dataset_displaynames(Dataset_switches == 1);
num_datasets = length(Dataset_names);

sample_sums = zeros(num_datasets, num_subset_sizes, num_samples);

dataset_sizes = nan(num_datasets);
dataset_mass = nan(num_datasets);
sample_sizes = nan(num_datasets, num_subset_sizes);

for data_idx = 1:num_datasets
    data_name = Dataset_names{data_idx};
    A = read_graph(data_name);
    n = size(A, 1);
    
    fprintf('DATASET: %s (size %d)\n', Dataset_names{data_idx}, n);
    dataset_sizes(data_idx) = n;
    dataset_mass(data_idx) = sum(A(:)/2);
    sample_sizes(data_idx, :) = floor(sqrt(n));
    deg = sum(A, 1)';
    m = sum(deg)/2;
    for s_idx = 1:num_subset_sizes
        fprintf('s_idx: %d\n', s_idx);
        for sample_idx = 1:num_samples
            k = sample_sizes(data_idx, s_idx);
            S = randsample(n, k);
            A_S = A(S,S);
            sample_sums(data_idx, s_idx, sample_idx) = sum(A_S(:)) / 2;
        end
    end
end

%% Plot: subgraph density plots

plot_cmd = @loglog;
gp_param = cell(num_datasets, num_subset_sizes);
linetypes = {'-', '--', '-.'};
for data_idx = 1:num_datasets
    data_name = Dataset_names{data_idx};
    figure('Units', 'pixels', 'Position', [100 100 500 500]);
    set(gca,'YScale','log');
    set(gcf, 'PaperPositionMode', 'auto');
    suptitle(Dataset_displaynames{data_idx});
    colors = distinguishable_colors(5);
    
    nrow = ceil(sqrt(num_subset_sizes));
    subplot(nrow,ceil(num_subset_sizes / nrow), s_idx);

    samp = squeeze(sample_sums(data_idx, s_idx, :));
    [ycdf,xcdf] = cdfcalc(samp);
    plot_cmd(xcdf, 1-ycdf(2:end), 'kx', 'LineWidth',3,'MarkerSize', 12); hold on;
    if ~all(sum(samp) == 0)
        pfit = paretotails(samp,0,gp_cutoff); 
        gp_param{data_idx, s_idx} = [quantile(samp, gp_cutoff) upperparams(pfit)];
        gpcdf = 1 - cdf(pfit, xcdf);
        plot_cmd(xcdf, gpcdf, '-','LineWidth', 3, 'Color', colors(1, :), 'LineStyle', linetypes{1}); hold on;
    end
    n = dataset_sizes(data_idx);
    s = sample_sizes(data_idx, s_idx);
    dens = dataset_mass(data_idx) / (n * (n-1) / 2);
    block_mean = dens * s * (s-1) / 2;
    pcdf = 1 - poisscdf(xcdf, block_mean);
    plot_cmd(xcdf, pcdf, '-', 'Color', colors(2, :),'LineWidth',3, 'LineStyle', linetypes{2}); hold on;
    gcdf = 1 - normcdf(xcdf, mean(samp), std(samp));
    plot_cmd(xcdf, gcdf, '-', 'Color', colors(3, :),'LineWidth',3, 'LineStyle', linetypes{3}); hold on;
    ylim([1e-4, .1]);
    xlabel('Subgraph mass');
    ylabel('Complementary CDF');
    set(findall(gcf,'Type','Axes'),'FontSize',20);
    set(findall(gcf,'Type','Text'),'FontSize',24);
    set(findall(gcf,'Type','Legend'),'FontSize',20);
    mylegend = legend({'Empirical', 'Generalized Pareto', 'Poisson', 'Gaussian'}, 'Location', 'southwest');
    printpdf(gcf, sprintf('../plots/emp_data/emp_data_%s.pdf', data_name), 'pdf');
    hold off;
end

disp(cell2table(gp_param, 'RowNames', Dataset_names));

