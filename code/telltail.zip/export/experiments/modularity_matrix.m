function M = modularity_matrix(A)
d = sum(A)';
m = sum(d)/2;
M = A - d * d' / (2*m);
end