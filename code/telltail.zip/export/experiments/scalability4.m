% SCALABILITY - RUN TELLTAIL ONLY TO FIND TIME IN SECONDS

clear all; close all; clc;

cd ~/Desktop/bryan-papers/dense/empirical/code/
addpath distinguishable_colors/

cols = mycolors();
markers = mymarkers();

method_names = {'TellTail'};
num_methods = length(method_names);

%% LINEAR SCALABILITY PLOT


av_deg = 10;
num_ns = 9;

ns_arr = round((.7).^(0:num_ns-1) * 20000);
% ns_arr1 = round(ns_arr/12); % for tail1+2
ns_arr1 = ns_arr;
time_taken = nan(num_methods, num_ns);
num_edges = nan(3, num_ns);
num_iters = 500; % for tail3

%%

% for ns_idx = 1:num_ns
%     ns = ns_arr1(ns_idx);
%     fprintf('ns=%d\n', ns);
%     A = random_erdos_renyi(ns, av_deg / ns);
%     x = rand(ns,1) < 0.5;
%     
%     tic;
%     [gp_sums, gp_adjsums] = tail_train(A, 1000, ns);
%     metric_tail(A, x, gp_sums);
%     time_taken(1, ns_idx) = toc;
%     num_edges(1, ns_idx) = sum(A(:))/2;
% 
%     tic;
%     [gp_sums, gp_adjsums] = tail_train(A, 1000, ns);
%     metric_adjsums(A, x, gp_adjsums);
%     time_taken(2, ns_idx) = toc;
%     num_edges(2, ns_idx) = sum(A(:))/2;
% end

%%

for ns_idx = 1:num_ns
    ns = ns_arr1(ns_idx);
    fprintf('ns=%d\n', ns);
    A = random_erdos_renyi(ns, av_deg / ns);
    x = rand(ns,1) < 0.5;
    tic;
    for i=1:num_iters
        metric_tail3(A, x);
    end
    time_taken(3, ns_idx) = toc/num_iters;
    num_edges(3, ns_idx) = sum(A(:))/2;
end

%%
% load Saved' Results'/time_taken.mat
% save('Saved Results/time_taken.mat', 'time_taken', 'num_edges');

fig = figure('Position', [0 0 500 500]);
method_names = {'Tail', 'TailDC', 'TellTail'};
for method_idx = 1:3
    E = num_edges(method_idx, :);
    loglog(E, time_taken(method_idx, :),'-x', 'LineWidth',3, 'Marker', markers{method_idx}, 'MarkerSize', 15, 'Color', cols(method_idx, :)); hold on;
    xlabel('Number of edges', 'FontSize', 24);
    ylabel('Time taken (s)', 'FontSize', 24);
end
% set(gca, 'FontSize', 20);
% title(method_names{method_idx}, 'FontSize', 28, 'FontWeight' , 'bold');
xl = get(gca,'xlim');
% x1 = E(end);
% x2 = E(1);
x1 = xl(2);
x2 = xl(1);
y1 = time_taken(method_idx, end);
y2 = y1 * x2 / x1;
loglog([x1 x2], 1e6*[y1 y2], 'k--', 'LineWidth',2); hold on;
loglog([x1 x2], 1e2*[y1 y2], 'k--', 'LineWidth',2); hold on;
legend({'Tail', 'TailDC', 'TellTail'}, 'Location', 'northwest');

set(findall(fig,'-property','FontSize'),'FontSize',24);
set(gcf, 'PaperPositionMode', 'auto');
printpdf(gcf, '../plots/scalability3.pdf','pdf');
hold off;

fprintf('ratios:\n');
fprintf('%.3f ', time_taken(1,:) ./ time_taken(3,:)); 
fprintf('\n');
