function score = tail_score(x, params)
% params: mu, xzi, sigma
% score = -log(1 - cdf(pfit, x));
xzi = params(2);
z = (x - params(1)) / params(3);
if xzi * z < -1
    score = nan;
elseif any(isnan(params))
    score = 0;
elseif abs(xzi) < 1e-5
    score = z;
else
    score = 1 + log1p(xzi * z) / (xzi * log(10));
end
end