import numpy as np
import operator
import cPickle as pickle
import math
import csv

TIME_LOG_BASE = 5

def load_swm(use_products):
	csvfile = open('../data/swm/swm3_reviews_meta.csv', 'rb')
	outfile = open('test_out.txt', 'w')
	reader = csv.reader(csvfile, delimiter=',', escapechar='\\', quotechar=None)
	ratings = {} # {user: [(prod, time, rating)]}
	usermap = {}
	# note: users are labelled 1 through (num_users) without gaps
	for toks in reader:
		user, username, prod, rating, time = [toks[2], toks[3], toks[0], int(toks[4]), int(toks[9])]
		usermap[user] = username
		if use_products:
			user, prod = prod, user
		if user not in ratings: 
			ratings[user] = []
		ratings[user].append((prod, time, rating))
		print >> outfile, '%s' %(user,)
	return ratings, usermap


def load_flipkart(use_products):
	fin = open('../data/flipkart/prod-ratings-simple.txt', 'r')
	ratings = {} # {user: [(prod, time, rating)]}
	for line in fin:
		user, prod, rating, time = [int(x) for x in line.split()[0:4]]
		if use_products: user, prod = prod, user	
		if user not in ratings: 
			ratings[user] = []
		ratings[user].append((prod, time, rating))
	return ratings, None

def process_data(ratings, dataname, use_products):

	keyword = 'prod' if use_products else 'user'
	rating_arr = []
	iat_arr = []
	ids = []
	max_time_diff = -1
	for user in ratings:
		cur_ratings = sorted(ratings[user], key=operator.itemgetter(1))
		for i in range(1, len(cur_ratings)):
			time_diff = cur_ratings[i][1] - cur_ratings[i-1][1]
			max_time_diff = max(max_time_diff, time_diff)

	S = int(1 + math.floor(math.log(1 + max_time_diff, TIME_LOG_BASE)))
	for user in ratings:
		if len(ratings[user]) <= 1: continue
		rating_counts = [0] * 5
		iat_counts = [0] * S
		cur_ratings = sorted(ratings[user], key=operator.itemgetter(1))
		rating_counts[cur_ratings[0][2] - 1] += 1
		for i in range(1, len(cur_ratings)):
			time_diff = cur_ratings[i][1] - cur_ratings[i-1][1]
			iat_bucket = int(math.floor(math.log(1 + time_diff, TIME_LOG_BASE)))
			rating_counts[cur_ratings[i][2] - 1] += 1
			iat_counts[iat_bucket] += 1
		rating_arr.append(rating_counts)
		iat_arr.append(iat_counts)
		ids.append(user)

	with open('../data/%s/%s_rating_bucketed.txt' % (dataname, keyword), 'w') as rating_file:
		for row in rating_arr:
			print >> rating_file, ' '.join([str(x) for x in row])

	with open('../data/%s/%s_iat_bucketed.txt' % (dataname, keyword), 'w') as iat_file:
		for row in iat_arr:
			print >> iat_file, ' '.join([str(x) for x in row])

	rating_arr = np.array(rating_arr)
	iat_arr = np.array(iat_arr)
	return (rating_arr, iat_arr, ids)