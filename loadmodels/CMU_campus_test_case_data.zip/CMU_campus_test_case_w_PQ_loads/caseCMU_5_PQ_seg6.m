function mpc = caseCMU_5_PQ_seg6
%% 5 bus case representing the Carnegie Mellon University campus (Segment 6)
% Test case developed by Marko Jereminov (mjeremin@andrew.cmu.edu) as a
% suplementary material to the publication: 
% M. Jereminov, B. Hooi, A. Pandey, H. A. Song, C. Faloutsos and L. Pileggi, "Impact of Load Models on Power Flow Optimization," 2019 IEEE PES GM
% Created: October 2018
% Load parameters obtained using PowerFit algorithm:
% M. Jereminov, A. Pandey, H. A. Song, B. Hooi, C. Faloutsos and L. Pileggi, "Linear load model for robust power system analysis," 2017 IEEE PES ISGT-Europe, Torino, 2017, pp. 1-6.
%% MATPOWER Case Format : Version 2
mpc.version = '2';
%%-----  Power Flow Data  -----%%
%% system MVA base
mpc.baseMVA = 200;
%% bus data
%	bus_i	type	Pd	Qd	Gs	Bs	area	Vm	Va	baseKV	zone	Vmax	Vmin
mpc.bus = [
	1	3	0	0	0	0	1	1.03782452	  0       345	1	1.06	0.94;
	2	1	134.18	44.687	0	0	1	0.95   -3.50  	345	1	1.04	0.96;
	3	1	193.37	64.402	0	0	1	0.95   -3.27  	345	1	1.04	0.96;
	4	1	98.116  32.677	0	0	1	1.04   34.65 	345	1	1.04	0.96;
	5	2	0	0	0	0	1	1.059999923   41.77 	345	1	1.06	0.94;	
    ];
%% generator data
%	bus	Pg	     Qg	   Qmax	    Qmin	Vg	mBase	status	Pmax	Pmin	Pc1	Pc2	Qc1min	Qc1max	Qc2min	Qc2max	ramp_agc	ramp_10	ramp_30	ramp_q	apf
mpc.gen = [
	1	0   	61.221	250	    -250	1.03782452	100	      1	    700 	0	0	0	0	0	0	0	0	0	0	0	0;
	5	439.15 	49.806	    250	    -250	1.059999923	100	      1	    450  	0	0	0	0	0	0	0	0	0	0	0	0;
];
%% branch data
%	fbus	tbus	r	x	b	rateA	rateB	rateC	ratio	angle	status	angmin	angmax
mpc.branch = [
	1	2	0.02	0.09	   0.0     2500	2500	2500	0	0	1	-360	360;
	1	3	0.02	0.08       0.0     2500	2500	2500	0	0	1	-360	360;
	2	4	0.01  	0.07	   0.5    2500	2500	2500	0	0	1	-360	360;
	3	5	0.01    0.07	   0.5    2500	2500	2500	0	0	1	-360	360;
	4	5	0.02    0.08       0.0     2500	2500	2500	0	0	1	-360	360;
	2	3	0.01 	0.09       0.0     2500	2500	2500	0	0	1	-360	360;
];
%%-----  OPF Data  -----%%
%% generator cost data
%	1	startup	shutdown	n	x1	y1	...	xn	yn
%	2	startup	shutdown	n	c(n-1)	...	c0
mpc.gencost = [
	2	2000	0	3	0	0.7000 	0;
	2	2000	0	3	0	0.3800	0;	
];
end