function mymarkers = mymarkers()
mymarkers = {'x', 'o', 'diamond',  'v', 'square',  '^', '>','<','*', '+', 'p', 'h'};
end